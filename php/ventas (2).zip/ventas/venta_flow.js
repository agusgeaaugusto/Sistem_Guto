/* venta_flow.js (vFinal+) — Ticket y Factura sin cruces, con cotizaciones y pago */
(() => {
  if (window.__ventaFlowV5) return;
  window.__ventaFlowV5 = true;

  // === CONFIG: a qué archivo apunta la FACTURA ===
  // 'imprimir_factura.php'              -> factura estilo ticket 80mm
  // 'imprimir_factura_preimpresa.php'   -> factura A4 preimpresa (solo datos)
  const FACTURA_URL = 'imprimir_factura.php'; // cambia a 'imprimir_factura_preimpresa.php' si usas planilla A4

  // ========= Utils =========
  const toNumber = (v) => {
    if (v == null) return 0;
    const s = String(v).trim();
    if (!s) return 0;
    const clean = s.replace(/[^\d,.\-]/g, '');
    if (clean.includes('.') && clean.includes(',')) return parseFloat(clean.replace(/\./g, '').replace(',', '.')) || 0;
    if (/^\d+,\d{1,2}$/.test(clean)) return parseFloat(clean.replace(',', '.')) || 0;
    return parseFloat(clean.replace(',', '')) || 0;
  };

  const leerCotiz = (sel, fallback) => {
    const el = document.querySelector(sel);
    if (!el) return fallback;
    const n = Number(String(el.textContent || '').replace(/[^\d,.-]/g, '').replace(',', '.'));
    return Number.isFinite(n) && n > 0 ? Math.round(n) : fallback;
  };

  const COTIZ = {
    br: leerCotiz('#cotizacion-real', 1450),   // R$
    usd: leerCotiz('#cotizacion-dolar', 7600) // US$
  };

  const totales = (items) => {
    let total = 0;
    items.forEach(it => total += (Number(it.cantidad) || 1) * (Number(it.precio) || 0));
    return { total };
  };

  const mapeaProducto = (p) => ({
    id_producto:   p.id_producto ?? p.id_pro ?? p.id ?? null,
    codigo:        p.codigo ?? p.codigo_barra ?? p.codigo_barra_pro ?? p.barcode ?? null,
    descripcion:   p.descripcion ?? p.nombre ?? p.nombre_pro ?? 'Producto',
    cantidad:      Number(p.cantidad ?? p.qty ?? 1),
    precio:        Number(p.precio ?? p.precio_unit ?? p.unit_price ?? 0),
    tipo_impuesto: String(p.tipo_impuesto ?? p.iva ?? '10')
  });

  // ===== Parser DOM (fallback) =====
  function leerCarritoDesdeTabla() {
    const rows = document.querySelectorAll('#tbody-carrito tr, table.carrito tbody tr, table[data-role="carrito"] tr, table#carrito tr');
    const items = [];
    rows.forEach((row) => {
      const ths = row.querySelectorAll('th');
      const tds = row.querySelectorAll('td');
      if (ths.length || tds.length === 0) return;
      const cellTxt = (i) => (tds[i]?.textContent || '').trim();
      const codigo = cellTxt(0);
      const nombre = cellTxt(1);
      const cantInp = tds[2]?.querySelector('input,select');
      const cantidad = toNumber(cantInp ? cantInp.value : cellTxt(2)) || 1;
      const precInp = tds[3]?.querySelector('input,select');
      const precio = toNumber(precInp ? precInp.value : cellTxt(3));
      const idAttr = row.dataset.idProducto || row.dataset.id_producto || row.dataset.id || null;
      const id_producto =
        idAttr != null ? (String(idAttr).match(/^\d+$/) ? Number(idAttr) : idAttr)
        : (String(codigo).match(/^\d+$/) ? Number(codigo) : null);
      if (!codigo && !nombre) return;
      items.push({ id_producto, codigo: codigo || null, descripcion: nombre || 'Producto', cantidad, precio });
    });
    return items;
  }

  const leerCarrito = () => {
    try { if (window.CartUI?.getItems) { const arr = CartUI.getItems() || []; if (arr.length) return arr.map(mapeaProducto); } } catch (_){}
    try { if (Array.isArray(window.Cart?.items) && window.Cart.items.length) return window.Cart.items.map(mapeaProducto); } catch (_){}
    if (Array.isArray(window.carrito) && window.carrito.length) return window.carrito.map(mapeaProducto);
    return leerCarritoDesdeTabla();
  };

  // ===== Navegación / helpers =====
  const basePathJoin = (rel) => {
    const loc = window.location;
    const norm = rel.replace(/^\/+/, '');
    if (/\/php\/ventas\//.test(loc.pathname)) {
      const dir = loc.pathname.replace(/[^/]+$/, '');
      return dir + norm;
    }
    return '/php/ventas/' + norm;
  };

  const openNew = (url) => {
    const w = window.open(url, '_blank', 'noopener');
    if (!w) {
      const a = document.createElement('a');
      a.href = url; a.target = '_blank'; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); setTimeout(() => a.remove(), 300);
    }
  };

  const limpiarUI = () => {
    try {
      if (Array.isArray(window.carrito)) window.carrito.length = 0;
      if (window.CartUI?.clear) CartUI.clear();
      window.renderizarCarrito?.();
    } catch (_){}
    ['#input-guarani', '#input-real', '#input-dolar'].forEach(sel => { const el = document.querySelector(sel); if (el) el.value=''; });
    (document.getElementById('codigo-barra') || document.querySelector('input[type=search]'))?.focus();
  };

  const toggleBotones = (disabled) => {
    ['btn-cobro-rapido', 'btn-cobro-rapido-ticket', 'btn-factura-legal'].forEach(id => {
      const el = document.getElementById(id); if (el) el.disabled = disabled;
    });
  };

  // ===== Guardar + imprimir =====
  let guardando = false;
  window.guardarVenta = async function(tipo){
    if (guardando) return;
    guardando = true;
    toggleBotones(true);
    try {
      // 1) Ítems y total
      const items = leerCarrito();
      if (!items.length) throw new Error('El carrito está vacío.');
      const { total } = totales(items);

      // 2) Pagos (parse robusto)
      const g = toNumber(document.querySelector('#input-guarani')?.value);
      const r = toNumber(document.querySelector('#input-real')?.value);
      const u = toNumber(document.querySelector('#input-dolar')?.value);
      const brGs  = Math.round((r || 0) * COTIZ.br);
      const usdGs = Math.round((u || 0) * COTIZ.usd);
      const recibidoGs = Math.max(0, (Math.round(g) || 0) + brGs + usdGs);
      const vuelto = Math.max(0, recibidoGs - total);
      const partes = [];
      if (g) partes.push(`₲ ${g.toLocaleString('es-PY')}`);
      if (r) partes.push(`R$ ${r.toLocaleString('es-PY', { minimumFractionDigits: 2 })}`);
      if (u) partes.push(`US$ ${u.toLocaleString('es-PY', { minimumFractionDigits: 2 })}`);
      const recibidoTxt = partes.join(' + ') || '₲ 0';

      // 3) Cliente
      const id_per  = document.body.dataset.cliId || document.getElementById('cliente-id')?.value || null;
      const cli_nom = document.body.dataset.cliNombre || document.getElementById('cliente-nombre')?.value || 'CONSUMIDOR FINAL';
      const cli_doc = document.body.dataset.cliRuc || document.getElementById('cliente-ruc')?.value || '';
      const cli_dir = document.body.dataset.cliDir || '';

      // 4) Guardar
      const payload = {
        id_per, cliente_nombre: cli_nom, cliente_doc: cli_doc, cliente_dir: cli_dir,
        carrito: items, total, tipo,
        pago: { moneda: 'mix', recibido: recibidoGs, vuelto }
      };
      const resp = await fetch('guardar_venta.php', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
      });
      let json; try { json = await resp.json(); } catch { throw new Error('Respuesta inválida del servidor'); }
      if (!resp.ok || !json.ok) throw new Error(json?.mensaje || 'No se guardó la venta');
      const id_venta = json.id_venta || json.id || json.idVenta;
      if (!id_venta) throw new Error('El servidor no devolvió id_venta');

      // 5) Imprimir (Ticket ≠ Factura)
      const ts = Date.now();

      if (tipo === 'ticket'){
        const qTicket = new URLSearchParams({
          id_venta: String(id_venta), id: String(id_venta),
          cliente_nombre: cli_nom || '', cliente_doc: cli_doc || '',
          cotiz_br: String(COTIZ.br), cotiz_usd: String(COTIZ.usd),
          recibido_txt: recibidoTxt, recibido: String(recibidoGs),
          vuelto: String(vuelto), ts: String(ts)
        });
        openNew(basePathJoin(`imprimir_ticket.php?${qTicket.toString()}`));
      }

      if (tipo === 'factura'){
        const qFac = new URLSearchParams({
          id_venta: String(id_venta), id: String(id_venta),
          razon: cli_nom || '', ruc: cli_doc || '', direccion: cli_dir || '',
          ts: String(ts)
        });
        openNew(basePathJoin(`${FACTURA_URL}?${qFac.toString()}`));
      }

      // 6) Limpiar
      limpiarUI();

    } catch (err) {
      console.error(err);
      alert('Error al guardar: ' + (err.message || err));
    } finally {
      toggleBotones(false);
      guardando = false;
    }
  };

  // ===== Enlazar botones =====
  const safeBind = (id, tipo) => {
    const el = document.getElementById(id);
    if (!el || el.dataset.bound === '1') return;
    el.dataset.bound = '1';
    el.addEventListener('click', (e) => { e.preventDefault(); window.guardarVenta?.(tipo); });
  };

  window.addEventListener('DOMContentLoaded', () => {
    safeBind('btn-cobro-rapido', 'venta');        // guarda sin imprimir
    safeBind('btn-cobro-rapido-ticket', 'ticket');
    safeBind('btn-factura-legal', 'factura');     // <-- enlaza el botón nuevo
    // Atajo de teclado: F9 para Factura (no uses F12, abre DevTools)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'F9') { e.preventDefault(); window.guardarVenta?.('factura'); }
    });
  });
})();
