<?php
// ventas.php - Carvallo Bodega (pantalla de ventas)
// Nota: Este archivo es mayormente HTML/JS. PHP aquí es solo para extensión/servido.
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Carvallo Bodega - Pantalla de Ventas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="venta.css" />

  <style>
  /* ====== Layout principal ====== */
  .container-pantalla { display:flex; flex-direction:row; justify-content:space-between; gap:20px; }
  .left-panel { padding:10px; }
  @media (max-width:768px){
    .container-pantalla { flex-direction:column; }
    .left-panel,.right-panel { width:100%; }
  }

  /* ====== Tabs de la derecha ====== */
  .rp-tabs { display:flex; gap:8px; padding:6px; border-bottom:1px solid #ccc; }
  .rp-tab { padding:8px 12px; border:1px solid #ccc; border-radius:6px; background:#f3f4f6; cursor:pointer; }
  .rp-tab.active { background:#111827; color:#fff; }

  /* ====== Resumen de pago ====== */
  .resumen-pago { margin-top:10px; border-top:1px dashed #ddd; padding-top:8px; }
  .fila-resumen { margin:4px 0; }

  /* ====== Modal ====== */
  .modal.hidden { display:none !important; }
  .modal { position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,.45); z-index:1000; }
  .modal .modal-content { background:#fff; width:min(520px,92vw); border-radius:12px; padding:18px 20px; box-shadow:0 10px 30px rgba(0,0,0,.24); }
  .modal .actions { display:flex; gap:12px; justify-content:flex-end; margin-top:12px; }
  .modal input { width:100%; padding:10px 12px; border:1px solid #d1d5db; border-radius:10px; margin:8px 0; }

  /* ====== Botones globales ====== */
  button { appearance:none; border:none; border-radius:8px; padding:10px 16px; font-size:14px; font-weight:600; font-family:inherit; cursor:pointer; background:#2563eb; color:#fff; transition:background-color .2s ease, transform .1s ease; }
  button:hover { background:#1e40af; }
  button:active { transform:scale(0.97); }
  button:disabled { opacity:.5; cursor:not-allowed; }
  button.red { background:#dc2626; } button.red:hover{ background:#991b1b; }
  button.green{ background:#16a34a; } button.green:hover{ background:#166534; }
  button.gray { background:#6b7280; } button.gray:hover{ background:#374151; }

  /* ====== Botones cuadrados ====== */
  .btn-cuadrado{ display:inline-flex; align-items:center; justify-content:center; border:1px solid #333; background:#f5f5f5; color:#111;
                 padding:10px 12px; min-width:88px; min-height:38px; border-radius:6px; cursor:pointer; font-weight:600;
                 box-shadow:0 1px 0 rgba(0,0,0,0.05); transition:transform .05s ease, background .2s ease, box-shadow .2s ease; }
  .btn-cuadrado:hover{ background:#eaeaea; } .btn-cuadrado:active{ transform:translateY(1px); }
  .btn-cuadrado.primary{ background:#0ea5e9; border-color:#0ea5e9; color:#fff; }
  .btn-cuadrado.success{ background:#22c55e; border-color:#22c55e; color:#fff; }
  .btn-cuadrado.warn{ background:#f59e0b; border-color:#f59e0b; color:#fff; }

  /* ====== Tabla carrito ====== */
  table.carrito { width:100%; border-collapse:collapse; }
  table.carrito th, table.carrito td { border-bottom:1px solid #eee; padding:8px; text-align:left; }
  table.carrito th { background:#f9fafb; }

  header { font-weight:800; padding:10px 14px; }
  .cliente-visor{ margin:.5rem 0; font-weight:600; }
  .buscador-codigo{ display:flex; gap:8px; align-items:center; margin-top:8px; }
  .icono-moneda{ width:20px; height:20px; vertical-align:-4px; margin-right:6px; }
  </style>
</head>

<body>
<header>CARVALLO BODEGA</header>
<!-- FAB: Tema día/noche -->
<button id="fab-theme" class="ui-fab" title="Tema día/noche" aria-label="Tema">
  <span class="icon" id="icon-theme">🌙</span>
</button>

<!-- FAB: Fullscreen -->
<button id="fab-fullscreen" class="ui-fab" title="Pantalla completa" aria-label="Pantalla completa">
  <span class="icon">⤢</span>
</button>


<div class="container">
  <div class="container-pantalla">
    <!-- ====== PANEL IZQUIERDO ====== -->
    <div class="left-panel">

      <!-- Cliente -->
      <div class="cliente-info">
        <label for="cliente-ruc">RUC / C.I.:</label>
        <input type="text" id="cliente-ruc" placeholder="Ej: 4567890" />
        <label for="cliente-nombre">Nombre:</label>
        <input type="text" id="cliente-nombre" placeholder="Nombre del cliente" />
        <input type="hidden" id="cliente-id" name="cliente_id" />
      </div>

      <!-- Visor de cliente -->
      <div id="cliente-visor" class="cliente-visor">CONSUMIDOR FINAL (s/RUC)</div>

      <!-- Modal: nuevo cliente -->
      <div id="modal-nuevo-cliente" class="modal hidden" aria-hidden="true" aria-modal="true" role="dialog">
        <div class="modal-content">
          <h3>Nuevo cliente</h3>
          <form id="form-nuevo-cliente" autocomplete="off">
            <label for="nc-ruc">RUC / C.I.</label>
            <input type="text" id="nc-ruc" required />
            <label for="nc-nombre">Nombre / Razón social</label>
            <input type="text" id="nc-nombre" required />
            <div class="actions">
              <button type="button" id="nc-cancelar">Cancelar</button>
              <button type="submit" id="nc-guardar">Guardar</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Totales y Cotización -->
      <div class="contenedor-totales-cotizaciones">
        <div class="total">
          <h3>Total</h3>
          <div class="fila-monedas">
            <div class="moneda"><img src="../img/productos/guarani.png" alt="Guaraní" class="icono-moneda"><strong id="espejo-total-guarani">₲ 0</strong></div>
            <div class="moneda"><img src="../img/productos/real.png" alt="Real" class="icono-moneda"><strong id="espejo-total-real">R$ 0,00</strong></div>
            <div class="moneda"><img src="../img/productos/dolar.png" alt="Dólar" class="icono-moneda"><strong id="espejo-total-dolar">US$ 0,00</strong></div>
          </div>
        </div>
        <div class="cotizacion">
          <h3>Cotización</h3>
          <div class="fila-monedas">
            <div class="moneda"><img src="../img/productos/guarani.png" alt="Guaraní" class="icono-moneda"><strong id="cotizacion-guarani">₲ 0</strong></div>
            <div class="moneda"><img src="../img/productos/real.png" alt="Real" class="icono-moneda"><strong id="cotizacion-real">R$ 0</strong></div>
            <div class="moneda"><img src="../img/productos/dolar.png" alt="Dólar" class="icono-moneda"><strong id="cotizacion-dolar">US$ 0</strong></div>
          </div>
        </div>
      </div>

      <!-- Carrito -->
      <div class="factura">
        <table class="carrito">
          <thead>
            <tr>
              <th>Código</th>
              <th>Producto</th>
              <th>Cant.</th>
              <th>Precio Unit.</th>
              <th>Subtotal</th>
              <th>Eliminar</th>
            </tr>
          </thead>
          <tbody id="tbody-carrito"><!-- filas dinámicas --></tbody>
        </table>
      </div>

      <!-- Buscador -->
      <div class="buscador-codigo">
        <input type="text" id="codigo-barra" placeholder="Escanear o ingresar código de barra" />
        <button id="btn-buscar-producto">Adicionar al Carrito</button>
      </div>

      <!-- Botones inferiores -->
      <div class="bottom-buttons" style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">
        <button class="red" id="btn-remover-item">Remover</button>
        <button id="btn-pagar-vender">💵 Finalizar Venta</button>
        <div class="grupo-precios" style="display:inline-flex; gap:6px;">
          <button id="btnPrecio1" class="precio-btn activo">Precio 1</button>
          <button id="btnPrecio2" class="precio-btn">Precio 2</button>
          <button id="btnPrecio3" class="precio-btn">Precio 3</button>
        </div>
      </div>
    </div>

    <!-- ====== PANEL DERECHO ====== -->
    <div class="right-panel" style="display:flex; flex-direction:column; height:100%; gap:20px;">

      <!-- Tabs -->
      <div class="rp-tabs">
        <button class="rp-tab active" data-target="panel-accesos">Acceso Rápido</button>
        <button class="btn-cuadrado rp-tab" data-target="panel-finalizar">Finalizar Venta</button>
      </div>

      <!-- Contenido -->
      <div class="rp-content" style="flex:1; overflow-y:auto;">

        <!-- Sección Finalizar Venta -->
        <section id="panel-finalizar" hidden>
          <!-- Resumen espejo derecha -->
          <div class="resumen-pago" style="margin-bottom:10px;">
            <div class="fila-resumen"><strong>Total Gs:</strong> <span id="derecha-total-guarani">₲ 0</span></div>
            <div class="fila-resumen"><strong>Total R$:</strong> <span id="derecha-total-real">R$ 0,00</span></div>
            <div class="fila-resumen"><strong>Total US$:</strong> <span id="derecha-total-dolar">US$ 0,00</span></div>
          </div>

          <div class="calculadora-horizontal" style="display:flex; gap:16px;">
            <!-- Inputs a la izquierda -->
            <div class="lado-izquierdo" style="flex:1;">
              <!-- Guaraní -->
              <div class="moneda">
                <img src="../img/productos/guarani.png" alt="Guaraní" class="icono-moneda">
                <small id="resta-guarani" class="estado-moneda" aria-live="polite">Falta: ₲ 0</small>
              </div>
              <div class="campo-moneda" style="display:flex; gap:6px; align-items:center;">
                <img src="../img/productos/guarani.png" alt="₲" class="icono-moneda">
                <input type="number" id="input-guarani" inputmode="numeric" step="1" min="0" autocomplete="off" aria-describedby="resta-guarani" />
              </div>

              <!-- Real -->
              <div class="moneda">
                <img src="../img/productos/real.png" alt="Real" class="icono-moneda">
                <small id="resta-real" class="estado-moneda" aria-live="polite">Falta: R$ 0,00</small>
              </div>
              <div class="campo-moneda" style="display:flex; gap:6px; align-items:center;">
                <img src="../img/productos/real.png" alt="R$" class="icono-moneda">
                <input type="number" id="input-real" inputmode="decimal" step="0.01" min="0" autocomplete="off" aria-describedby="resta-real" />
              </div>

              <!-- Dólar -->
              <div class="moneda">
                <img src="../img/productos/dolar.png" alt="Dólar" class="icono-moneda">
                <small id="resta-dolar" class="estado-moneda" aria-live="polite">Falta: US$ 0,00</small>
              </div>
              <div class="campo-moneda" style="display:flex; gap:6px; align-items:center;">
                <img src="../img/productos/dolar.png" alt="US$" class="icono-moneda">
                <input type="number" id="input-dolar" inputmode="decimal" step="0.01" min="0" autocomplete="off" aria-describedby="resta-dolar" />
              </div>
            </div>

            <!-- Teclado a la derecha -->
            <div class="lado-derecho" style="width:220px;">
              <div class="teclado" id="teclado" style="display:grid; grid-template-columns:repeat(3,1fr); gap:8px;">
                <button data-key="1">1</button><button data-key="2">2</button><button data-key="3">3</button>
                <button data-key="4">4</button><button data-key="5">5</button><button data-key="6">6</button>
                <button data-key="7">7</button><button data-key="8">8</button><button data-key="9">9</button>
                <button data-key="0">0</button><button data-key=".">.</button><button data-key="BACK">←</button>
              </div>
              <div id="estado-pago" style="font-weight:600; margin-top:8px;"></div>
            </div>
          </div>

          <div class="botones-cobro" style="margin-top:14px; display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn-cuadrado" id="btn-cobro-rapido">Cobro Rápido</button>
            <button class="btn-cuadrado ticket" id="btn-cobro-rapido-ticket">Cobro Rápido con Ticket</button>
            <button class="btn-cuadrado f12" id="btn-factura-legal">Factura Legal F12</button>
          </div>
        </section>

        <!-- Sección Acceso Rápido -->
        <section id="panel-accesos">
          <h3>Acceso Rápido</h3>
          <div class="product-grid" id="panelFavoritos">
            <!-- Favoritos dinámicos -->
            <div class="add-card" id="btnAbrirModalFavorito">+</div>
          </div>
        </section>
      </div>
    </div>
  </div>
</div>

<!-- ====== Tus scripts modulares (opcionales) ====== -->
<script src="precio_selector.js"></script>
<script src="main.js"></script>
<script src="carrito_y_favorito.js"></script>
<script src="pagos.js"></script>
<script src="calculadora.js"></script>
<script src="cliente.js"></script>
<script src="productos-modal.js"></script>
<script src="venta_flow.js?v=4"></script>


<!-- ====== Espejos de totales (protegido) ====== -->
<script>
window.addEventListener('DOMContentLoaded', () => {
  if (window.CartUI?.onChange && CartUI._fmt && CartUI._fromGs) {
    CartUI.onChange(({ subtotalGs }) => {
      const f = CartUI._fmt, conv = CartUI._fromGs;
      document.querySelector('#derecha-total-guarani')
        ?.replaceChildren(document.createTextNode(f.fmtGs(conv.guarani(subtotalGs))));
      document.querySelector('#derecha-total-real')
        ?.replaceChildren(document.createTextNode(f.fmtReal(conv.real(subtotalGs))));
      document.querySelector('#derecha-total-dolar')
        ?.replaceChildren(document.createTextNode(f.fmtDolar(conv.dolar(subtotalGs))));
    });
  }
});
</script>

<!-- ====== Tabs derecha ====== -->
<script>
document.querySelectorAll('.rp-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.rp-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.rp-content section').forEach(sec => sec.hidden = true);
    document.getElementById(btn.dataset.target).hidden = false;
  });
});
</script>

<!-- ====== Lógica autónoma de guardarVenta (integrada) ====== -->
<script>
(() => {
  if (window.__ventaFlowV3) return; window.__ventaFlowV3 = true;

  const toNumber = (v) => {
    if (v == null) return 0;
    const s = String(v).trim();
    if (!s) return 0;
    const clean = s.replace(/[^\d,.\-]/g, '');
    if (clean.includes('.') && clean.includes(',')) return parseFloat(clean.replace(/\./g,'').replace(',','.')) || 0;
    if (/^\d+,\d{1,2}$/.test(clean)) return parseFloat(clean.replace(',','.')) || 0;
    return parseFloat(clean.replace(',', '')) || 0;
  };

  const leerCotiz = (sel, fallback) => {
    const el = document.querySelector(sel);
    if (!el) return fallback;
    const n = Number(String(el.textContent || '').replace(/[^\d,.-]/g, '').replace(',', '.'));
    return Number.isFinite(n) && n > 0 ? Math.round(n) : fallback;
  };

  const COTIZ = {
    br: leerCotiz('#cotizacion-real', 1450),
    usd: leerCotiz('#cotizacion-dolar', 7600)
  };

  const mapeaProducto = (p) => ({
    id_producto:   p.id_producto ?? p.id_pro ?? p.id ?? null,
    codigo:        p.codigo ?? p.codigo_barra ?? p.codigo_barra_pro ?? p.barcode ?? null,
    descripcion:   p.descripcion ?? p.nombre ?? p.nombre_pro ?? 'Producto',
    cantidad:      Number(p.cantidad ?? p.qty ?? 1),
    precio:        Number(p.precio ?? p.precio_unit ?? p.unit_price ?? 0),
    tipo_impuesto: String(p.tipo_impuesto ?? p.iva ?? '10')
  });

  const leerCarrito = () => {
    try {
      if (window.CartUI && typeof CartUI.getItems === 'function') {
        const raw = CartUI.getItems();
        return (Array.isArray(raw) ? raw : []).map(mapeaProducto);
      }
    } catch (_) {}
    try {
      if (window.Cart && Array.isArray(Cart.items)) {
        return Cart.items.map(mapeaProducto);
      }
    } catch (_) {}
    if (Array.isArray(window.carrito)) return window.carrito.map(mapeaProducto);
    return [];
  };

  const totales = (items) => {
    let ex=0,t5=0,t10=0;
    items.forEach(it => {
      const sub = (Number(it.cantidad)||1) * (Number(it.precio)||0);
      const iva = String(it.tipo_impuesto ?? '10').toLowerCase();
      if (iva==='exenta' || iva==='0') ex+=sub;
      else if (iva==='5') t5+=sub;
      else t10+=sub;
    });
    return { exentas:ex, iva5:t5, iva10:t10, liq5:Math.round(t5/21), liq10:Math.round(t10/11), total: ex+t5+t10 };
  };

  const leerPago = (totalGs) => {
    const g = Math.round(toNumber(document.querySelector('#input-guarani')?.value));
    const r = toNumber(document.querySelector('#input-real')?.value);
    const u = toNumber(document.querySelector('#input-dolar')?.value);
    const brGs = Math.round((r||0) * COTIZ.br);
    const usdGs = Math.round((u||0) * COTIZ.usd);
    const recibidoGs = Math.max(0, (g||0) + brGs + usdGs);
    const vuelto = Math.max(0, recibidoGs - (Number(totalGs)||0));
    let partes = [];
    if (g) partes.push(`₲ ${g.toLocaleString('es-PY')}`);
    if (r) partes.push(`R$ ${r.toLocaleString('es-PY',{minimumFractionDigits:2})}`);
    if (u) partes.push(`US$ ${u.toLocaleString('es-PY',{minimumFractionDigits:2})}`);
    const recibidoTxt = partes.join(' + ') || '₲ 0';
    return { recibidoGs, recibidoTxt, vuelto };
  };

  const basePathJoin = (rel) => {
    const loc = window.location;
    if (/\/php\/ventas\//.test(loc.pathname)) {
      const dir = loc.pathname.replace(/[^/]+$/, '');
      return dir + rel.replace(/^\//,'');
    }
    return '/php/ventas/' + rel.replace(/^\//,'');
  };

  const openNew = (url) => {
    const w = window.open(url, '_blank', 'noopener');
    if (w) return;
    const a = document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener';
    document.body.appendChild(a); a.click(); setTimeout(()=>a.remove(), 300);
  };

  const limpiarUI = () => {
    try {
      if (Array.isArray(window.carrito)) window.carrito.length = 0;
      if (window.CartUI && typeof CartUI.clear === 'function') CartUI.clear();
      if (typeof window.renderizarCarrito === 'function') window.renderizarCarrito();
    } catch(_) {}

    ['#input-guarani', '#input-real', '#input-dolar'].forEach(sel => {
      const el = document.querySelector(sel); if (el) el.value='';
    });
    const setTxt = (sel, txt) => { const el=document.querySelector(sel); if(el) el.textContent=txt; };
    setTxt('#espejo-total-guarani','₲ 0'); setTxt('#espejo-total-real','R$ 0,00'); setTxt('#espejo-total-dolar','US$ 0,00');
    setTxt('#derecha-total-guarani','₲ 0'); setTxt('#derecha-total-real','R$ 0,00'); setTxt('#derecha-total-dolar','US$ 0,00');
    (document.getElementById('codigo-barra') || document.querySelector('input[type=search]'))?.focus();
  };

  const toggleBotones = (disabled) => {
    ['btn-cobro-rapido','btn-cobro-rapido-ticket','btn-factura-legal'].forEach(id=>{
      const el=document.getElementById(id); if(el) el.disabled = disabled;
    });
  };

  // Exponer onClienteSeleccionado por si viene de otro módulo
  window.onClienteSeleccionado = (n) => {
    const nombre = n?.nombre || n?.nombre_per || 'CONSUMIDOR FINAL';
    const ruc    = n?.ruc || n?.ruc_ci || n?.cedula_per || '';
    const id     = n?.id || n?.id_persona || '';
    const dir    = n?.direccion || n?.dir || '';
    const visor  = document.getElementById('cliente-visor');
    if (visor) visor.textContent = `${nombre} (${ruc || 's/RUC'})`;
    const nombreEl=document.getElementById('cliente-nombre'); if(nombreEl) nombreEl.value=nombre;
    const rucEl   =document.getElementById('cliente-ruc'); if(rucEl) rucEl.value=ruc;
    const idEl    =document.getElementById('cliente-id'); if(idEl) idEl.value=id;
    document.body.dataset.cliNombre = nombre;
    document.body.dataset.cliRuc = ruc;
    document.body.dataset.cliId = id;
    document.body.dataset.cliDir = dir;
  };

  // ===== Guardar Venta (EXPORTED) =====
  let guardando = false;
  window.guardarVenta = async function(tipo){
    if (guardando) return;
    guardando = true; toggleBotones(true);
    try {
      const items = leerCarrito();
      if (!items.length) throw new Error('El carrito está vacío.');
      const t = totales(items);
      const { recibidoGs, recibidoTxt, vuelto } = leerPago(t.total);
      const id_per  = document.body.dataset.cliId || document.getElementById('cliente-id')?.value || null;
      const cli_nom = document.body.dataset.cliNombre || document.getElementById('cliente-nombre')?.value || 'CONSUMIDOR FINAL';
      const cli_doc = document.body.dataset.cliRuc || document.getElementById('cliente-ruc')?.value || '';
      const cli_dir = document.body.dataset.cliDir || '';

      const payload = {
        id_per: id_per,
        cliente_nombre: cli_nom,
        cliente_doc: cli_doc,
        cliente_dir: cli_dir,
        carrito: items,
        total: t.total,
        tipo, // 'venta' | 'ticket' | 'factura'
        pago: { moneda: 'mix', recibido: recibidoGs, vuelto }
      };

      const resp = await fetch('guardar_venta.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      let json; try{ json = await resp.json(); } catch{ throw new Error('Respuesta inválida del servidor'); }
      if (!resp.ok || !json.ok) throw new Error(json?.mensaje || 'No se guardó la venta');

      const id_venta = json.id_venta || json.id || json.idVenta;
      if (!id_venta) throw new Error('El servidor no devolvió id_venta');

      const ts = Date.now();
      if (tipo==='ticket' || tipo==='factura'){
        const qTicket = new URLSearchParams({
          id: String(id_venta),
          cliente_nombre: cli_nom || '',
          recibido_txt: recibidoTxt || '',
          vuelto: String(vuelto),
          ts: String(ts)
        });
        openNew(basePathJoin(`imprimir_ticket.php?${qTicket.toString()}`));
      }
      if (tipo==='factura'){
        const qFac = new URLSearchParams({
          id: String(id_venta),
          ruc: cli_doc || '',
          razon: cli_nom || '',
          direccion: cli_dir || '',
          ts: String(ts)
        });
        openNew(basePathJoin(`imprimir_factura.php?${qFac.toString()}`));
      }

      limpiarUI();
    } catch(err){
      console.error(err);
      alert('Error al guardar: ' + (err.message || err));
    } finally {
      toggleBotones(false);
      guardando = false;
    }
  };

  // Cablear botones (por si no hay otro módulo haciéndolo)
  const safeBind = (id, tipo) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.dataset.bound === '1') return;
    el.dataset.bound = '1';
    el.addEventListener('click', (e)=>{ e.preventDefault(); window.guardarVenta?.(tipo); });
  };
  window.addEventListener('DOMContentLoaded', () => {
    safeBind('btn-cobro-rapido','venta');
    safeBind('btn-cobro-rapido-ticket','ticket');
    safeBind('btn-factura-legal','factura');
  });

})();</script>

<script>
(() => {
  const root = document.documentElement;
  const body = document.body;
  const themeBtn = document.getElementById('fab-theme');
  const themeIcon = document.getElementById('icon-theme');
  const fsBtn = document.getElementById('fab-fullscreen');

  // Tema persistente en localStorage (opcional y seguro)
  const savedTheme = localStorage.getItem('ui.theme');
  if (savedTheme === 'light') {
    root.classList.add('theme-light');
    if (themeIcon) themeIcon.textContent = '☀️';
  }

  themeBtn?.addEventListener('click', () => {
    root.classList.toggle('theme-light');
    const isLight = root.classList.contains('theme-light');
    localStorage.setItem('ui.theme', isLight ? 'light' : 'dark');
    if (themeIcon) themeIcon.textContent = isLight ? '☀️' : '🌙';
  });

  // Fullscreen “visual” (sin APIs del navegador, no rompe nada)
  fsBtn?.addEventListener('click', () => {
    body.classList.toggle('fullscreen');
  });
})();
</script>


</body>
</html>
