<?php
/** imprimir_factura_preimpresa.php (A4) — Carvallo Bodega
 * - Imprime SOLO datos sobre la factura preimpresa (ORIGINAL + DUPLICADO)
 * - Fecha: "01 DE OCTUBRE DEL 2025"
 * - X en CONTADO/CRÉDITO
 * - IVA por columna (Exentas / 5% / 10%), con 0 en las otras
 * - Total en letras
 * - Calibración: ?x= (mm) ?y= (mm) ?scale= (factor) ?debug=1
 */
declare(strict_types=1);
header('Content-Type: text/html; charset=UTF-8');

require_once __DIR__ . '/conexion_bi.php';
if (!isset($conexion) || !$conexion) { http_response_code(500); die('Sin conexión DB'); }

// ---------- Helpers ----------
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function nf0($n){ return number_format((float)$n, 0, ',', '.'); }
function nf2($n){ return number_format((float)$n, 2, ',', '.'); }

function hasCol($cn, $table, $col){
  $q = pg_query_params($cn, "SELECT 1 FROM information_schema.columns WHERE table_name=$1 AND column_name=$2 LIMIT 1", [$table, $col]);
  return $q && pg_num_rows($q) > 0;
}

// ==== número → letras (PY) ====
function _letras_basicas($n){
  static $u = ['', 'uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve',
               'diez','once','doce','trece','catorce','quince','dieciséis','diecisiete','dieciocho','diecinueve'];
  static $d = ['', 'diez','veinte','treinta','cuarenta','cincuenta','sesenta','setenta','ochenta','noventa'];
  static $c = ['', 'cien','doscientos','trescientos','cuatrocientos','quinientos','seiscientos','setecientos','ochocientos','novecientos'];
  if ($n == 0) return 'cero';
  if ($n < 20) return $u[$n];
  if ($n < 100){
    $t = intdiv($n, 10); $r = $n % 10;
    if ($n == 20) return 'veinte';
    if ($n < 30) return 'veinti' . ($r ? $u[$r] : '');
    return $d[$t] . ($r ? ' y ' . $u[$r] : '');
  }
  if ($n < 1000){
    $t = intdiv($n, 100); $r = $n % 100;
    if ($n == 100) return 'cien';
    return $c[$t] . ($r ? ' ' . _letras_basicas($r) : '');
  }
  if ($n < 1000000){
    $t = intdiv($n, 1000); $r = $n % 1000;
    $pref = ($t==1 ? 'mil' : _letras_basicas($t).' mil');
    return $pref . ($r ? ' ' . _letras_basicas($r) : '');
  }
  if ($n < 1000000000){
    $t = intdiv($n, 1000000); $r = $n % 1000000;
    $pref = ($t==1 ? 'un millón' : _letras_basicas($t).' millones');
    return $pref . ($r ? ' ' . _letras_basicas($r) : '');
  }
  if ($n < 1000000000000){
    $t = intdiv($n, 1000000000); $r = $n % 1000000000;
    $pref = ($t==1 ? 'mil millones' : _letras_basicas($t).' mil millones');
    return $pref . ($r ? ' ' . _letras_basicas($r) : '');
  }
  return (string)$n;
}
function numero_a_letras_guarani($monto,
  $monedaSing='GUARANÍ', $monedaPlur='GUARANÍES',
  $centSing='CENTAVO', $centPlur='CENTAVOS'
){
  $monto = (float)$monto;
  $entero = (int)floor($monto + 0.00001);
  $centavos = (int)round(($monto - $entero) * 100);
  $txt = _letras_basicas($entero);
  $txt = preg_replace('/\buno\b$/u', 'un', $txt);
  $txt .= ' ' . ($entero==1 ? $monedaSing : $monedaPlur);
  if ($centavos > 0){
    $txtCent = _letras_basicas($centavos);
    $txtCent = preg_replace('/\buno\b$/u', 'un', $txtCent);
    $txt .= ' CON ' . $txtCent . ' ' . ($centavos==1 ? $centSing : $centPlur);
  }
  return mb_strtoupper($txt, 'UTF-8');
}

// ==== Fecha PY ====
function mes_py_mayus($n){
  static $m = ['ENERO','FEBRERO','MARZO','ABRIL','MAYO','JUNIO','JULIO','AGOSTO','SETIEMBRE','OCTUBRE','NOVIEMBRE','DICIEMBRE'];
  $n = max(1, min(12, (int)$n));
  return $m[$n-1];
}
function fecha_py($ts){
  $d = (int)date('d',$ts);
  $m = mes_py_mayus((int)date('n',$ts));
  $y = (int)date('Y',$ts);
  return sprintf('%02d DE %s DEL %04d', $d, $m, $y);
}

// ---------- Parámetros ----------
$id_venta = isset($_GET['id_venta']) ? intval($_GET['id_venta']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);
if ($id_venta <= 0) { http_response_code(400); die('Falta id_venta'); }

$offx   = isset($_GET['x']) ? floatval($_GET['x']) : 0;   // mm
$offy   = isset($_GET['y']) ? floatval($_GET['y']) : 0;   // mm
$scale  = isset($_GET['scale']) ? floatval($_GET['scale']) : 1.0;
$debug  = isset($_GET['debug']) ? intval($_GET['debug']) : 0;

// ---------- Venta ----------
$qv = pg_query_params($conexion, 'SELECT * FROM venta WHERE id_venta=$1', [$id_venta]);
if (!$qv || pg_num_rows($qv) === 0) { http_response_code(404); die('Venta no encontrada'); }
$venta = pg_fetch_assoc($qv);

// Fecha a imprimir
$ts_fecha = isset($venta['fecha_venta']) ? @strtotime($venta['fecha_venta']) : time();
if (!$ts_fecha) $ts_fecha = time();
$fecha_imp = fecha_py($ts_fecha);

// Cliente
$cli_nom = $_GET['razon'] ?? $_GET['cliente_nombre'] ?? ($venta['cliente_nombre'] ?? null);
$cli_doc = $_GET['ruc']   ?? $_GET['cliente_doc']     ?? ($venta['cliente_doc'] ?? null);
$cli_dir = $_GET['dir']   ?? $venta['cliente_dir']    ?? '';
if (!$cli_nom) $cli_nom = 'CONSUMIDOR FINAL';
if (!$cli_doc) $cli_doc = '';

// Condición (X en contado/crédito)
$cond_raw  = $_GET['cond'] ?? ($venta['condicion_venta'] ?? $venta['condicion'] ?? 'CONTADO');
$cond      = strtoupper(trim($cond_raw));
$isCredito = in_array($cond, ['CREDITO','CRÉDITO']);

// ---------- Detalle ----------
$vd_cols = [];
$detCols = pg_query_params($conexion, "SELECT column_name FROM information_schema.columns WHERE table_name=$1", ['venta_detalle']);
if ($detCols) while($r = pg_fetch_assoc($detCols)) $vd_cols[$r['column_name']] = true;

$hasIdPro = isset($vd_cols['id_pro']);
$join = $hasIdPro && hasCol($conexion, 'producto', 'id_pro') ? "LEFT JOIN producto p ON p.id_pro = d.id_pro" : "";

$descExpr = "''";
if (isset($vd_cols['nombre_pro'])) $descExpr = "COALESCE(d.nombre_pro, '')";
if ($hasIdPro && hasCol($conexion,'producto','nombre_pro')) $descExpr = "COALESCE(p.nombre_pro, ".$descExpr.", '')";
if (isset($vd_cols['descripcion'])) $descExpr = "COALESCE(d.descripcion, ".$descExpr.")";

$cantExpr = isset($vd_cols['cantidad']) ? "d.cantidad" : (isset($vd_cols['cantidad_det_ven']) ? "d.cantidad_det_ven" : "0");
$precExpr = isset($vd_cols['precio_unit']) ? "d.precio_unit" : (isset($vd_cols['precio']) ? "d.precio" : (isset($vd_cols['precio_venta']) ? "d.precio_venta" : "0"));
$subtExpr = isset($vd_cols['subtotal']) ? "d.subtotal" : "({$cantExpr} * {$precExpr})";
$ivaExpr  = isset($vd_cols['tipo_impuesto']) ? "LOWER(COALESCE(d.tipo_impuesto,'10'))"
          : (isset($vd_cols['iva']) ? "LOWER(COALESCE(d.iva,'10'))" : "'10'");

$order = isset($vd_cols['orden']) ? "ORDER BY d.orden NULLS LAST, d.id_pro"
       : ($hasIdPro ? "ORDER BY d.id_pro" : "");

$sql = "SELECT ".($hasIdPro ? "d.id_pro, " : "").
       $descExpr." AS descripcion, ".
       "COALESCE({$cantExpr},0) AS cantidad, ".
       "COALESCE({$precExpr},0) AS precio_unit, ".
       "COALESCE({$subtExpr},0) AS subtotal, ".
       $ivaExpr." AS iva_tipo ".
       "FROM venta_detalle d ".$join." WHERE d.id_venta=$1 ".$order;

$qd = pg_query_params($conexion, $sql, [$id_venta]);

$items = [];
if ($qd) while($d = pg_fetch_assoc($qd)){
  $items[] = [
    'codigo'      => isset($d['id_pro']) ? $d['id_pro'] : '',
    'descripcion' => $d['descripcion'] ?: '',
    'cantidad'    => (float)$d['cantidad'],
    'precio_unit' => (float)$d['precio_unit'],
    'subtotal'    => (float)$d['subtotal'],
    'iva_tipo'    => (string)$d['iva_tipo'],
  ];
}

// ---------- Totales ----------
$total = (float)($venta['total_venta'] ?? $venta['total'] ?? 0);
if ($total <= 0) { // por si no vino total en venta
  foreach ($items as $it) $total += $it['subtotal'];
}
$ex = 0; $t5 = 0; $t10 = 0;
foreach ($items as $it) {
  $iva = strtolower(trim($it['iva_tipo']));
  if ($iva==='exenta' || $iva==='0') $ex += $it['subtotal'];
  elseif ($iva==='5') $t5 += $it['subtotal'];
  else $t10 += $it['subtotal'];
}
$liq5  = round($t5/21);
$liq10 = round($t10/11);
$total_en_letras = numero_a_letras_guarani($total);

// ---------- Layout (mm) ----------
$vars = [
  '--form-top-1'   => '18mm',   // top primer cuerpo
  '--form-top-2'   => '165mm',  // top segundo cuerpo
  '--form-left'    => '18mm',   // margen izq
  '--col-cod'      => '0mm',
  '--col-cant'     => '24mm',
  '--col-desc'     => '40mm',
  '--col-punit'    => '150mm',
  '--col-exentas'  => '170mm',
  '--col-iva5'     => '184mm',
  '--col-iva10'    => '198mm',
  '--row-top'      => '62mm',   // primera fila
  '--row-h'        => '6.2mm',  // alto fila
  '--rows-max'     => '10',     // filas por cuerpo
  '--font'         => '11pt',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Factura Preimpresa</title>
<style>
  @page { size: A4; margin: 0; }
  html, body { margin:0; padding:0; }
  .page { position:relative; width: 210mm; height: 297mm; }
  .canvas { position:absolute; left: <?= $offx ?>mm; top: <?= $offy ?>mm; width: 210mm; height: 297mm; transform: scale(<?= $scale ?>); transform-origin: 0 0; }
  .form { position:absolute; left: <?= $vars['--form-left'] ?>; width: 175mm; height: 130mm; font-family: 'Courier New', monospace; font-size: <?= $vars['--font'] ?>; color:#000; }
  .f1 { top: <?= $vars['--form-top-1'] ?>; } .f2 { top: <?= $vars['--form-top-2'] ?>; }
  .field { position:absolute; white-space:nowrap; }
  .cod    { left: <?= $vars['--col-cod'] ?>; text-align:left; width: 20mm; }
  .cant   { left: <?= $vars['--col-cant'] ?>; text-align:center; width: 12mm; }
  .desc   { left: <?= $vars['--col-desc'] ?>; text-align:left; width: 108mm; overflow:hidden; }
  .punit  { left: <?= $vars['--col-punit'] ?>; text-align:right; width: 18mm; }
  .exen   { left: <?= $vars['--col-exentas'] ?>; text-align:right; width: 12mm; }
  .iva5   { left: <?= $vars['--col-iva5'] ?>; text-align:right; width: 12mm; }
  .iva10  { left: <?= $vars['--col-iva10'] ?>; text-align:right; width: 12mm; }
  .row { position:absolute; left:0; right:0; height: <?= $vars['--row-h'] ?>; }
  .r { text-align:right; }

  /* Campos superiores */
  .fecha-num  { left: 128mm; top: 20mm; } /* "01 DE OCTUBRE DEL 2025" */
  .ruc        { left: 30mm;  top: 22mm; }
  .nombre     { left: 30mm;  top: 29mm; max-width: 120mm; overflow:hidden; }
  .dir        { left: 30mm;  top: 36mm; max-width: 120mm; overflow:hidden; }

  /* Contado / Crédito (X) */
  .cond-x     { position:absolute; font-weight:bold; }
  .cond-cont  { left: 151mm; top: 78mm; }
  .cond-cred  { left: 171mm; top: 78mm; }

  /* Totales inferiores */
  .parcial { left: 45mm; top: 112mm; }
  .total   { left: 45mm; top: 121mm; font-weight:bold; }
  .iva5tot { left: 160mm; top: 121mm; }
  .iva10tot{ left: 194mm; top: 121mm; }

  /* Total en letras (columna izquierda) */
  .sonletras  { left: 24mm; top: 121mm; width: 120mm; white-space:nowrap; overflow:hidden; }

  /* Duplica posiciones para el segundo cuerpo */
  .f2 .fecha-num { top: calc(20mm + 147mm); }
  .f2 .cond-cont { top: calc(78mm + 147mm); }
  .f2 .cond-cred { top: calc(78mm + 147mm); }
  .f2 .sonletras { top: calc(121mm + 147mm); }

  <?php if($debug): ?>
  .form::before{ content:''; position:absolute; inset:0; border:1px dashed red; }
  .row{ outline: 1px dotted rgba(0,0,255,.3); }
  <?php endif; ?>
</style>
</head>
<body onload="window.print && window.print();">
  <div class="page">
    <div class="canvas">
      <?php
      function pintar_form($topClass, $items, $cli_nom, $cli_doc, $cli_dir, $fecha_imp, $ex, $t5, $t10, $liq5, $liq10, $total, $isCredito){
        $rowTop = 62.0; $rowH = 6.2; $rowsMax = 10;
        ?>
        <div class="form <?= $topClass ?>">
          <!-- Cabecera -->
          <div class="field fecha-num"><?= h($fecha_imp) ?></div>
          <div class="field ruc"><?= h($cli_doc) ?></div>
          <div class="field nombre"><?= h($cli_nom) ?></div>
          <div class="field dir"><?= h($cli_dir) ?></div>

          <!-- Condición -->
          <div class="cond-x cond-cont"><?= $isCredito ? '' : 'X' ?></div>
          <div class="cond-x cond-cred"><?= $isCredito ? 'X' : '' ?></div>

          <!-- Filas -->
          <?php for ($i=0; $i<$rowsMax; $i++):
            $y  = $rowTop + $i*$rowH;
            $it = $items[$i] ?? null;
            $esEx = $it && (strtolower($it['iva_tipo'])==='exenta' || (string)$it['iva_tipo']==='0');
            $es5  = $it && (string)$it['iva_tipo']==='5';
            $es10 = $it && !$esEx && !$es5;

            $vEx  = $it ? ($esEx  ? nf0($it['subtotal']) : '0') : '';
            $v5   = $it ? ($es5   ? nf0($it['subtotal']) : '0') : '';
            $v10  = $it ? ($es10  ? nf0($it['subtotal']) : '0') : '';
          ?>
            <div class="row" style="top: <?= $y ?>mm;">
              <div class="field cod"><?=    $it ? h($it['codigo'])       : '' ?></div>
              <div class="field cant"><?=   $it ? nf0($it['cantidad'])    : '' ?></div>
              <div class="field desc"><?=   $it ? h($it['descripcion'])   : '' ?></div>
              <div class="field punit"><?=  $it ? nf0($it['precio_unit']) : '' ?></div>
              <div class="field exen"><?=   $it ? $vEx  : '' ?></div>
              <div class="field iva5"><?=   $it ? $v5   : '' ?></div>
              <div class="field iva10"><?=  $it ? $v10  : '' ?></div>
            </div>
          <?php endfor; ?>

          <!-- Totales -->
          <div class="field parcial"><?= nf0($ex + $t5 + $t10) ?></div>
          <div class="field total"><?= nf0($ex + $t5 + $t10) ?></div>
          <div class="field iva5tot"><?= nf0($liq5) ?></div>
          <div class="field iva10tot"><?= nf0($liq10) ?></div>

          <!-- Total en letras -->
          <div class="field sonletras"><?= h(numero_a_letras_guarani($total)) ?></div>
        </div>
        <?php
      }
      pintar_form('f1', $items, $cli_nom, $cli_doc, $cli_dir, $fecha_imp, $ex, $t5, $t10, $liq5, $liq10, $total, $isCredito);
      pintar_form('f2', $items, $cli_nom, $cli_doc, $cli_dir, $fecha_imp, $ex, $t5, $t10, $liq5, $liq10, $total, $isCredito);
      ?>
    </div>
  </div>
</body>
</html>
