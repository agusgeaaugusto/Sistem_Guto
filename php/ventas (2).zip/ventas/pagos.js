 // Mapear etiquetas
  CartUI.configureSelectors({
    // IZQUIERDA = TOTAL (intacto)
    leftGs:  '#espejo-total-guarani',
    leftReal:'#espejo-total-real',
    leftUsd: '#espejo-total-dolar',

    // DERECHA = RESTANTE/VUELTO
    totGs:   '#restante-guarani',
    totReal: '#restante-real',
    totUsd:  '#restante-dolar',

    // (OPCIONAL) DERECHA = TOTAL espejado
    rightTotalGs:   '#derecha-total-guarani',
    rightTotalReal: '#derecha-total-real',
    rightTotalUsd:  '#derecha-total-dolar',
  });

  // Tasas del día (Gs por 1 R$ y 1 US$)
  CartUI.setRates({ real: 1450, dolar: 7600 });

  // Subtotal inicial (en ₲) — actualizalo cuando renderices el carrito
  CartUI.setSubtotalGs(0);

  // Si tu lógica recalcula el subtotal global:
  // document.dispatchEvent(new CustomEvent('carrito:cambio', { detail: { subtotalGs: nuevoSubtotal } }));