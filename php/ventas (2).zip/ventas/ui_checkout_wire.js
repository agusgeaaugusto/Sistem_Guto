// === ui_checkout_wire.js (mejorado) ===
import { buildPayloadFromUI, guardarVenta } from './venta_helpers.js';
function byTextContains(...subs){ const all=[...document.querySelectorAll('button, a, .btn')]; return all.find(el=>{ const t=(el.textContent||'').toLowerCase(); return subs.every(s=> t.includes(s)); }); }
function wireCheckoutButtons(){
  let bCR=document.getElementById('btn-cobro-rapido')||byTextContains('cobro','rápido');
  let bIF=document.getElementById('btn-imprimir-factura')||byTextContains('factura');
  let bIT=document.getElementById('btn-imprimir-ticket')||byTextContains('ticket');
  if(bCR){ bCR.addEventListener('click', async e=>{ e.preventDefault(); const res=await guardarVenta(buildPayloadFromUI()); if(res?.url_ticket) window.open(res.url_ticket,'_blank','noopener'); if(res?.url_factura) window.open(res.url_factura,'_blank','noopener'); }); }
  if(bIF){ bIF.addEventListener('click', async e=>{ e.preventDefault(); const res=await guardarVenta(buildPayloadFromUI()); if(typeof abrirPreviewFactura==='function'){ abrirPreviewFactura({id_venta:res.id_venta,nrofactura:res.nrofactura,total:res.total,vuelto:res.vuelto,items:[]}); } else if(res?.url_factura){ window.open(res.url_factura,'_blank','noopener'); } }); }
  if(bIT){ bIT.addEventListener('click', async e=>{ e.preventDefault(); const res=await guardarVenta(buildPayloadFromUI()); if(res?.url_ticket) window.open(res.url_ticket,'_blank','noopener'); }); }
}
document.readyState==='loading'?document.addEventListener('DOMContentLoaded',wireCheckoutButtons):wireCheckoutButtons();
