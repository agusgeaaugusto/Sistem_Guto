<?php
/**
 * guardar_venta.php
 * Guarda venta + detalles + ticket + factura.
 * Descuenta STOCK por lotes (FIFO) en productodetalle.
 */

declare(strict_types=1);
header('Content-Type: application/json; charset=UTF-8');

require_once __DIR__ . '/conexion_bi.php';

function fail(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'msg' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}
function ok(array $d, int $code = 201): void {
    http_response_code($code);
    echo json_encode(['ok' => true] + $d, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!$conexion) fail("Sin conexión a la base de datos", 500);

/**
 * DESCONTAR STOCK POR LOTES (FIFO)
 * Descuenta de productodetalle.cantidad_uni_pro ordenado por fecha de vencimiento.
 */
function descontar_stock_fifo($conexion, int $id_pro, float $cantidad): void {

    // Obtener LOTES pendientes (FIFO)
    $sqlLotes = "
        SELECT id_det_pro, cantidad_uni_pro
        FROM productodetalle
        WHERE id_pro = $1 AND cantidad_uni_pro > 0
        ORDER BY fecha_ven_pro ASC NULLS LAST, id_det_pro ASC
    ";
    $res = pg_query_params($conexion, $sqlLotes, [$id_pro]);

    if (!$res) {
        throw new Exception("Error buscando lotes: " . pg_last_error($conexion));
    }

    $restante = $cantidad;

    while ($restante > 0 && ($lote = pg_fetch_assoc($res))) {

        $id_det_pro = intval($lote['id_det_pro']);
        $stock_lote = floatval($lote['cantidad_uni_pro']);

        if ($stock_lote <= 0) continue;

        if ($stock_lote >= $restante) {
            // El lote cubre todo
            $nuevo = $stock_lote - $restante;
            $upd = pg_query_params($conexion,
                "UPDATE productodetalle SET cantidad_uni_pro = $1 WHERE id_det_pro = $2",
                [$nuevo, $id_det_pro]
            );
            if (!$upd) throw new Exception(pg_last_error($conexion));
            $restante = 0; // Ya cubierto
        } else {
            // El lote se agota
            $upd = pg_query_params($conexion,
                "UPDATE productodetalle SET cantidad_uni_pro = 0 WHERE id_det_pro = $1",
                [$id_det_pro]
            );
            if (!$upd) throw new Exception(pg_last_error($conexion));
            $restante -= $stock_lote;
        }
    }

    if ($restante > 0) {
        throw new Exception("Stock insuficiente para el producto $id_pro");
    }
}


// Leer payload JSON
$raw = file_get_contents("php://input");
$payload = json_decode($raw ?: "{}", true);
if (!is_array($payload)) $payload = $_POST;

// Carrito
$items = $payload["items"] ?? $payload["carrito"] ?? [];
if (!is_array($items) || count($items) === 0) fail("Carrito vacío.", 422);


// Datos generales
$descuento   = floatval($payload["descuento_venta"] ?? 0);
$total_in    = $payload["total_venta"] ?? null;
$recibido    = floatval($payload["recibido"] ?? 0);
$vuelto      = floatval($payload["vuelto"] ?? ($recibido - ($total_in ?? 0)));
$id_per      = isset($payload["id_per"]) ? intval($payload["id_per"]) : null;
$id_usuario  = isset($payload["id_usuario"]) ? intval($payload["id_usuario"]) : null;
$id_comp     = isset($payload["id_comprobante"]) ? intval($payload["id_comprobante"]) : null;
$estado      = (string)($payload["estado_venta"] ?? "CER");
$obs         = trim($payload["observacion"] ?? "");


// Recalcular totales
$total_calc = 0;
$calc_items = [];

foreach ($items as $it) {
    $id_pro  = intval($it["id_pro"]);
    $cant    = floatval($it["cantidad"]);
    $precio  = floatval($it["precio"]);
    $sub     = $cant * $precio;

    if ($id_pro <= 0 || $cant <= 0) fail("Ítem inválido", 422);

    $total_calc += $sub;

    $calc_items[] = [
        "id_pro" => $id_pro,
        "cant"   => $cant,
        "precio" => $precio,
        "sub"    => $sub
    ];
}

$total_final = ($total_in !== null) ? floatval($total_in) : $total_calc;
$total_final = round($total_final - $descuento, 2);
$vuelto      = max(0, $recibido - $total_final);


// INICIO TRANSACCIÓN
pg_query($conexion, "BEGIN");

try {

    // Insertar venta
    $res = pg_query_params($conexion,
        "INSERT INTO venta(fecha_venta, descuento_venta, total_venta, estado_venta, id_per, id_usuario, id_comprobante, recibido, vuelto, observacion)
         VALUES (now(), $1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id_venta",
        [$descuento, $total_final, $estado, $id_per, $id_usuario, $id_comp, $recibido, $vuelto, $obs]
    );
    if (!$res) throw new Exception(pg_last_error($conexion));

    $id_venta = intval(pg_fetch_result($res, 0, 0));

    // Insertar detalles + descontar stock FIFO
    foreach ($calc_items as $d) {

        pg_query_params(
            $conexion,
            "INSERT INTO venta_detalle(id_venta, id_pro, cantidad, precio_unit, subtotal)
             VALUES ($1,$2,$3,$4,$5)",
            [$id_venta, $d["id_pro"], $d["cant"], $d["precio"], $d["sub"]]
        );

        descontar_stock_fifo($conexion, $d["id_pro"], $d["cant"]);
    }

    // Generar ticket y factura (bloqueando)
    pg_query($conexion, "LOCK TABLE ticket IN EXCLUSIVE MODE");
    pg_query($conexion, "LOCK TABLE factura IN EXCLUSIVE MODE");

    $nextT = pg_fetch_result(pg_query($conexion, "SELECT COALESCE(MAX(numero),0)+1 FROM ticket"), 0, 0);
    $nextF = pg_fetch_result(pg_query($conexion, "SELECT COALESCE(MAX(numero),0)+1 FROM factura"), 0, 0);

    $rt = pg_query_params($conexion,
        "INSERT INTO ticket(id_venta, numero, fecha) VALUES ($1,$2, now()) RETURNING numero",
        [$id_venta, $nextT]
    );
    $rf = pg_query_params($conexion,
        "INSERT INTO factura(id_venta, numero, fecha) VALUES ($1,$2, now()) RETURNING numero",
        [$id_venta, $nextF]
    );

    $nroticket  = intval(pg_fetch_result($rt, 0, 0));
    $nrofactura = intval(pg_fetch_result($rf, 0, 0));

    pg_query($conexion, "COMMIT");

    ok([
        "id_venta"    => $id_venta,
        "nroticket"   => $nroticket,
        "nrofactura"  => $nrofactura,
        "total"       => $total_final,
        "vuelto"      => $vuelto,
        "clearCarrito"=> true
    ]);

} catch (Throwable $e) {
    pg_query($conexion, "ROLLBACK");
    fail("Error al guardar venta: " . $e->getMessage(), 500);
}

?>
