let cotizaciones = {
    guarani: 1,
    real: 1250,
    dolar: 7200
};

function cargarCotizaciones() {
    fetch('get_cotizaciones.php')
        .then(res => res.json())
        .then(data => {
            cotizaciones = { ...cotizaciones, ...data };
            document.getElementById('cotizacion-guarani').innerText = `₲ ${cotizaciones.guarani}`;
            document.getElementById('cotizacion-real').innerText = `R$ ${cotizaciones.real}`;
            document.getElementById('cotizacion-dolar').innerText = `US$ ${cotizaciones.dolar}`;
        })
        .catch(err => {
            console.warn('No se pudieron cargar las cotizaciones:', err);
        });
}

function buscarProducto() {
    const entrada = document.getElementById("codigo-barra").value.trim();
    if (!entrada) return alert("Por favor, ingresa un código de barra.");

    let cantidad = 1;
    let codigo = entrada;

    if (entrada.includes("*")) {
        const partes = entrada.split("*");
        cantidad = parseInt(partes[0]) || 1;
        codigo = partes[1];
    }

    fetch('listar_productos.php')
        .then(res => res.json())
        .then(response => {
            if (!response.success) return alert("Error al buscar productos.");
            const producto = response.data.find(p => p.codigo_barra_pro === codigo);
            if (!producto) return alert("Producto no encontrado");
            agregarAlCarrito(producto, cantidad);
            document.getElementById("codigo-barra").value = "";
        })
        .catch(err => console.error("Error al buscar producto:", err));
}

document.addEventListener("DOMContentLoaded", () => {
    cargarCotizaciones();
    cargarFavoritos();

    document.getElementById("codigo-barra").addEventListener("keypress", function(e) {
        if (e.key === "Enter") {
            buscarProducto();
        }
    });

    document.querySelectorAll(".precio-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".precio-btn").forEach(b => b.classList.remove("activo"));
            btn.classList.add("activo");

            if (btn.id === "btnPrecio1") precioSeleccionado = "precio1_pro";
            else if (btn.id === "btnPrecio2") precioSeleccionado = "precio2_pro";
            else if (btn.id === "btnPrecio3") precioSeleccionado = "precio3_pro";

            console.log("Precio seleccionado:", precioSeleccionado);
        });
    });

    $('#precio1_pro, #precio2_pro, #precio3_pro').on('input', function () {
        let valor = parseInt($(this).val().replace(/\./g, '')) || 0;
        $(this).val(new Intl.NumberFormat('es-ES').format(valor));
    });
});

let precioSeleccionado = 'precio1_pro';
