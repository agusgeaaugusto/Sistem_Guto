
import { TICKET_PRINTER_NAME } from './config_impresoras.js';

/** Utils **/
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
const fmt = (n)=> new Intl.NumberFormat('es-PY').format(n ?? 0);

function limpiarUI() {
  try { // intenta usar API del proyecto si existe
    if (window.Carrito?.vaciar) window.Carrito.vaciar();
    if (window.Pagos?.reset) window.Pagos.reset();
  } catch(e){ /* ignore */ }

  // Limpieza genérica de la UI
  const contCarrito = $('#carrito-lista, .carrito-lista, #lista-carrito');
  if (contCarrito) contCarrito.innerHTML = '';
  const totalEl = $('#total-venta, #totalVenta, .total-venta');
  if (totalEl) totalEl.textContent = '0';
  const recibidoEl = $('#recibido-input, #recibidoGs, #recibido');
  if (recibidoEl) recibidoEl.value = '';
  const vueltoEl = $('#vuelto, #vueltoGs, .vuelto');
  if (vueltoEl) vueltoEl.textContent = '0';
}

/** POST helper */
async function postJSON(url, data) {
  const rsp = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });
  if (!rsp.ok) throw new Error(`HTTP ${rsp.status}`);
  const j = await rsp.json().catch(()=> ({}));
  return j;
}

/** Ejecuta impresión del ticket en una nueva pestaña/ventana */
function imprimirTicket(id_venta) {
  const url = `imprimir_ticket.php?id_venta=${encodeURIComponent(id_venta)}&printer=${encodeURIComponent(TICKET_PRINTER_NAME)}`;
  window.open(url, '_blank');
}

/** Abre modal de FACTURA */
function abrirModalFactura({id_venta, total}){
  let modal = $('#modal-factura-auto');
  if (!modal){
    modal = document.createElement('div');
    modal.id = 'modal-factura-auto';
    modal.className = 'modal-auto hidden';
    modal.innerHTML = `
      <div class="modal-backdrop"></div>
      <div class="modal-card" role="dialog" aria-modal="true">
        <div class="modal-head">
          <h3>Factura</h3>
          <button class="btn-close" id="mf-cerrar">×</button>
        </div>
        <div class="modal-body">
          <div class="row">
            <label>Condición:</label>
            <select id="mf-condicion">
              <option value="CONTADO">CONTADO</option>
              <option value="CRÉDITO">CRÉDITO</option>
            </select>
          </div>
          <div class="row">
            <small>Total: <strong id="mf-total">0</strong> Gs.</small>
          </div>
          <div class="row">
            <label>Nº de Factura:</label>
            <input id="mf-numero" placeholder="(opcional si tu backend lo genera)" />
          </div>
        </div>
        <div class="modal-foot">
          <button id="mf-guardar" class="btn-primario">Guardar</button>
          <button id="mf-imprimir" class="btn-secundario">Imprimir</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    // estilos mínimos
    const style = document.createElement('style');
    style.textContent = `
    .modal-auto.hidden{display:none}
    .modal-auto{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center}
    .modal-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.5)}
    .modal-card{position:relative;background:#0f1217;border:1px solid #2b2f3b;border-radius:12px;padding:16px;min-width:320px;max-width:90vw;color:#d4d7e3}
    .modal-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
    .row{display:flex;gap:8px;align-items:center;margin:8px 0}
    select,input{background:#0a0d13;border:1px solid #2b2f3b;border-radius:8px;color:#d4d7e3;padding:8px}
    .btn-primario{background:#2563eb;border:1px solid #2563eb;color:#fff;border-radius:10px;padding:10px 12px}
    .btn-secundario{background:#0a0d13;border:1px solid #2b2f3b;color:#d4d7e3;border-radius:10px;padding:10px 12px}
    .btn-close{background:#0a0d13;border:1px solid #2b2f3b;color:#d4d7e3;border-radius:8px;padding:4px 10px}
    `;
    document.head.appendChild(style);

    $('#mf-cerrar', modal).addEventListener('click', ()=> modal.classList.add('hidden'));

    $('#mf-guardar', modal).addEventListener('click', async ()=>{
      const condicion = $('#mf-condicion').value;
      const nro = $('#mf-numero').value || null;

      try {
        const resp = await postJSON('guardar_venta.php', {
          es_factura: 1,
          condicion,
          nrofactura: nro
        });
        if (!resp?.ok) throw new Error(resp?.msg || 'No se pudo guardar factura');
        alert('Factura guardada.');
      } catch(e){
        alert('Error al guardar factura: '+ e.message);
      }
    });

    $('#mf-imprimir', modal).addEventListener('click', ()=>{
      const url = `imprimir_factura.php?id_venta=${encodeURIComponent(id_venta)}`;
      window.open(url,'_blank');
    });
  }

  $('#mf-total', modal).textContent = fmt(total ?? 0);
  modal.classList.remove('hidden');
}

/** COBRO RÁPIDO = guarda venta y manda directo a impresora TICKET + guarda info de factura mínima */
async function cobroRapido(payloadVenta) {
  // payloadVenta debe traer items, totales, recibido, etc. Si tu app ya prepara esto, perfecto.
  // Como fallback, intentamos leer del DOM:
  const total = payloadVenta?.total ?? parseInt($('#total-venta')?.textContent.replace(/\./g,'')) || 0;

  // 1) guardar venta (backend ya existente)
  let resp;
  try {
    resp = await postJSON('guardar_venta.php', {
      ...payloadVenta,
      cobro_rapido: 1,
      es_ticket: 1,
      es_factura: 1   // marcamos que también se guarde información básica para factura
    });
  } catch(e){
    alert('Error al guardar venta: '+ e.message);
    return;
  }
  if (!resp?.ok) {
    alert(resp?.msg || 'No se pudo guardar la venta.');
    return;
  }
  const id_venta = resp.id_venta ?? resp.id ?? null;

  // 2) imprimir ticket directamente
  if (id_venta) imprimirTicket(id_venta);

  // 3) limpiar toda la UI
  limpiarUI();
  // como último recurso, recargar para limpiar todo estado residual
  setTimeout(()=> location.reload(), 800);
}

/** CHANGE LABELS + HOOKS **/
function ensureActionBar(){
  // Si ya existen botones, sólo renombramos y conectamos; si no, creamos una barra flotante.
  let btnCR = $('#btn-cobro-rapido');
  let btnIF = $('#btn-imprimir-factura');
  let btnIT = $('#btn-imprimir-ticket');

  if (!btnCR || !btnIF || !btnIT){
    let bar = $('#barra-acciones-checkout');
    if (!bar){
      bar = document.createElement('div');
      bar.id = 'barra-acciones-checkout';
      bar.innerHTML = `
        <div class="checkout-bar">
          <button id="btn-cobro-rapido">Cobro Rápido</button>
          <button id="btn-imprimir-factura">Imprimir Factura</button>
          <button id="btn-imprimir-ticket">Imprimir Ticket</button>
        </div>`;
      document.body.appendChild(bar);
      const style = document.createElement('style');
      style.textContent = `
      .checkout-bar{position:fixed;right:16px;bottom:16px;display:flex;gap:8px;background:#0a0d13;border:1px solid #2b2f3b;border-radius:12px;padding:10px;z-index:9999}
      .checkout-bar button{cursor:pointer;border-radius:10px;padding:10px 12px;border:1px solid #2b2f3b;background:#121826;color:#d4d7e3}
      .checkout-bar button:hover{background:#0f1623}
      `;
      document.head.appendChild(style);
    }
    btnCR = $('#btn-cobro-rapido'); btnIF = $('#btn-imprimir-factura'); btnIT = $('#btn-imprimir-ticket');
  }

  // renombrar por si existían con otros textos:
  btnIF.textContent = 'Imprimir Factura';
  btnIT.textContent = 'Imprimir Ticket';

  // listeners
  btnCR.onclick = async ()=> {
    // prepara payload mínimo si tu app no lo pasa
    const items = window.Carrito?.items ?? [];
    const total = parseInt($('#total-venta')?.textContent.replace(/\./g,'')) || 0;
    const recibido = parseInt($('#recibidoGs')?.value?.replace(/\./g,'')) || total;
    const vuelto = Math.max(0, recibido - total);
    await cobroRapido({ items, total, recibido, vuelto });
  };

  btnIF.onclick = ()=> {
    const id = window.UltimaVentaID || $('#id-venta')?.textContent || '';
    const total = parseInt($('#total-venta')?.textContent.replace(/\./g,'')) || 0;
    if (!id) {
      // Si aún no hay venta, abrimos modal para guardar + imprimir
      abrirModalFactura({ id_venta: id, total });
    } else {
      abrirModalFactura({ id_venta: id, total });
    }
  };

  btnIT.onclick = ()=> {
    const id = window.UltimaVentaID || $('#id-venta')?.textContent || '';
    if (!id) { alert('Aún no hay venta para imprimir ticket. Usa Cobro Rápido o Guarda primero.'); return; }
    imprimirTicket(id);
  };
}

window.addEventListener('DOMContentLoaded', ensureActionBar);
