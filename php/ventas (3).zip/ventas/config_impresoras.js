// === Configuración de impresión ===
// Cambia este nombre por el de tu impresora térmica (Windows/macOS).
// En Linux/CUPS, usa el nombre de la cola.
//
// Ejemplo Windows: "EPSON TM-T20II Receipt"
// Ejemplo CUPS: "tm_t20ii"
export const TICKET_PRINTER_NAME = "NOMBRE_DE_TU_IMPRESORA";
