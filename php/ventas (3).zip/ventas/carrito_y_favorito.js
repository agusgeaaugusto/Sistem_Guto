// carrito_y_favorito.js — versión completa y corregida
// - Cada clic agrega una línea nueva (sin merge).
// - P1/P2/P3 solo afecta al PRÓXIMO ítem (no reprocesa líneas viejas).
// - Tras agregar, vuelve solo a P1 y marca el botón.
// - Limpieza post-venta borra filas, inputs y espejos.

///////////////////////////
// Estado global único
///////////////////////////
window.carrito = Array.isArray(window.carrito) ? window.carrito : [];
const carrito = window.carrito; // MISMA referencia

///////////////////////////
// Helpers
///////////////////////////
const $  = (s, c=document) => c.querySelector(s);
const $$ = (s, c=document) => Array.from(c.querySelectorAll(s));

function toNumber(v){
  if (v == null) return 0;
  const s = String(v).trim();
  if (!s) return 0;
  const clean = s.replace(/[^\d,.\-]/g,'');
  if (clean.includes('.') && clean.includes(',')) return parseFloat(clean.replace(/\./g,'').replace(',', '.')) || 0;
  if (/^\d+,\d{1,2}$/.test(clean)) return parseFloat(clean.replace(',', '.')) || 0;
  return parseFloat(clean.replace(',', '')) || 0;
}

function getCotizaciones(){
  const brTxt  = $('#cotizacion-real')?.textContent ?? '';
  const usdTxt = $('#cotizacion-dolar')?.textContent ?? '';
  return {
    real : Math.round(toNumber(brTxt))  || window.COT_BR  || 1450, // R$ -> Gs
    dolar: Math.round(toNumber(usdTxt)) || window.COT_USD || 7600  // US$ -> Gs
  };
}

function formatearMoneda(valor, tipo) {
  const n = Number(valor) || 0;
  switch (tipo) {
    case 'guarani':
      return `₲ ${Math.round(n).toLocaleString('es-PY')}`;
    case 'real':
      return `R$ ${n.toLocaleString('es-PY',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
    case 'dolar':
      return `US$ ${n.toLocaleString('es-PY',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
    default:
      return n.toLocaleString();
  }
}

///////////////////////////
// Resolver de precio (P1/P2/P3) con alias
///////////////////////////
function resolverPrecio(producto, nivel) {
  // normalizar a p1/p2/p3
  const nv = (nivel || '').toLowerCase();
  const tier = (nv === 'precio1_pro' || nv === 'p1' || nv === 'precio1' || nv === 'precio_1') ? 'p1' :
               (nv === 'precio2_pro' || nv === 'p2' || nv === 'precio2' || nv === 'precio_2') ? 'p2' :
               (nv === 'precio3_pro' || nv === 'p3' || nv === 'precio3' || nv === 'precio_3') ? 'p3' : 'p1';

  const keysPorTier = {
    p1: ['precio1_pro','precio1','precio_1','p1','precio'],
    p2: ['precio2_pro','precio2','precio_2','p2'],
    p3: ['precio3_pro','precio3','precio_3','p3']
  };

  // Primero, intentar las keys del tier elegido
  for (const k of keysPorTier[tier]) {
    const val = producto[k];
    if (val != null && !Number.isNaN(parseFloat(val))) {
      return { precio: parseFloat(val), key: k };
    }
  }
  // Fallback a P1
  for (const k of keysPorTier.p1) {
    const val = producto[k];
    if (val != null && !Number.isNaN(parseFloat(val))) {
      return { precio: parseFloat(val), key: k };
    }
  }
  return { precio: 0, key: 'precio' };
}

///////////////////////////
// Render del carrito
///////////////////////////
function renderizarCarrito() {
  const tbody = $(".carrito tbody") || $('table[data-role="carrito"] tbody') || $('#tbody-carrito');
  if (!tbody) return;

  tbody.innerHTML = "";
  let total = 0;

  carrito.forEach((producto, index) => {
    const cant     = Math.max(1, Number(producto.cantidad)||1);
    const precio   = Number(producto.precio) || 0;
    const subtotal = cant * precio;
    total += subtotal;

    const fila = document.createElement("tr");
    fila.innerHTML = `
      <td>${producto.codigo ?? producto.codigo_barra_pro ?? producto.codigo_barra ?? ''}</td>
      <td>${producto.nombre_pro ?? producto.descripcion ?? producto.nombre ?? 'Producto'}</td>
      <td>
        <input 
          type="number" 
          class="cantidad-input" 
          value="${cant}" 
          data-index="${index}" 
          min="1" 
          step="1" 
          title="Cantidad"
          style="width: 42px;"
        >
      </td>
      <td>${formatearMoneda(precio, 'guarani')}</td>
      <td>${formatearMoneda(subtotal, 'guarani')}</td>
      <td><button class="btn-remover" data-index="${index}" title="Quitar">🗑️</button></td>
    `;

    fila.querySelector('.cantidad-input').addEventListener('change', function () {
      const nuevaCantidad = Math.max(1, parseInt(this.value) || 1);
      carrito[index].cantidad = nuevaCantidad;
      renderizarCarrito();
    });

    fila.querySelector('.btn-remover').addEventListener('click', (e) => {
      const i = Number(e.currentTarget.dataset.index);
      removerDelCarrito(i);
    });

    // último agregado arriba
    tbody.prepend(fila);
  });

  // Totales / espejos
  const cot = getCotizaciones();

  // Espejos izquierda
  $('#espejo-total-guarani')?.replaceChildren(document.createTextNode(formatearMoneda(total, 'guarani')));
  $('#espejo-total-real')?.replaceChildren(document.createTextNode(formatearMoneda(total / (cot.real||1), 'real')));
  $('#espejo-total-dolar')?.replaceChildren(document.createTextNode(formatearMoneda(total / (cot.dolar||1), 'dolar')));

  // Panel derecho
  $('#derecha-total-guarani')?.replaceChildren(document.createTextNode(formatearMoneda(total, 'guarani')));
  $('#derecha-total-real')?.replaceChildren(document.createTextNode(formatearMoneda(total / (cot.real||1), 'real')));
  $('#derecha-total-dolar')?.replaceChildren(document.createTextNode(formatearMoneda(total / (cot.dolar||1), 'dolar')));

  // Compat: selectores antiguos si existen
  const totMon = $$('.total .moneda strong');
  if (totMon[0]) totMon[0].innerText = formatearMoneda(total, 'guarani');
  if (totMon[1]) totMon[1].innerText = formatearMoneda(total / (cot.real||1), 'real');
  if (totMon[2]) totMon[2].innerText = formatearMoneda(total / (cot.dolar||1), 'dolar');
}

///////////////////////////
// Mutadores
///////////////////////////
function removerDelCarrito(index) {
  if (index>=0 && index<carrito.length) {
    carrito.splice(index, 1);
    renderizarCarrito();
  }
}

// Cada clic = nueva fila, usa la lista seleccionada SOLO para ese ítem, y luego resetea a P1
function agregarAlCarrito(producto, cantidad = 1) {
  if (typeof window.precioSeleccionado !== 'string') window.precioSeleccionado = 'p1';

  const { precio, key } = resolverPrecio(producto, window.precioSeleccionado);

  // código principal “bonito” para mostrar
  const codigoPrincipal = producto.codigo_barra_pro ?? producto.codigo_barra ?? producto.codigo ?? producto.barcode ?? '';

  carrito.push({
    ...producto,
    codigo: codigoPrincipal,
    cantidad: Math.max(1, Number(cantidad) || 1),
    precio: parseFloat(precio) || 0,
    _precio_nivel: key // tracking opcional
  });

  renderizarCarrito();

  // Reset al Precio 1 para EL PRÓXIMO ítem y actualizar botones visuales
  window.precioSeleccionado = 'p1';
  ['btnPrecio1','btnPrecio2','btnPrecio3'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('activo', id === 'btnPrecio1');
  });
}

///////////////////////////
// Favoritos
///////////////////////////
function cargarFavoritos() {
  fetch('listar_productos.php')
    .then(response => response.json())
    .then(data => {
      if (!data || data.success === false || !Array.isArray(data.data)) {
        console.error("Error al cargar productos:", data);
        return;
      }
      const productos = data.data;
      const panel = document.getElementById("panelFavoritos");
      if (!panel) {
        console.error("No se encontró el contenedor #panelFavoritos");
        return;
      }

      panel.innerHTML = '<div class="add-card" id="btnAbrirModalFavorito">+</div>';

      productos.forEach(producto => {
        const esFavorito = (producto.favorito === true || producto.favorito === 1 || producto.favorito === "1");
        if (!esFavorito) return;

        const card = document.createElement('div');
        card.classList.add('product-card');
        card.style.cursor = 'pointer';
        card.innerHTML = `
          <div class="img-container">
            <img src="../img/productos/${producto.imagen_pro || 'sin_imagen.jpg'}"
                 alt="${producto.nombre_pro}" title="${producto.nombre_pro}">
          </div>
          <div class="name-container"><span>${producto.nombre_pro}</span></div>
        `;
        card.addEventListener("click", () => {
          const cantidad = obtenerCantidadDesdeInput();
          agregarAlCarrito(producto, cantidad);
          mostrarToast(`${cantidad} x ${producto.nombre_pro} agregados al carrito`);
        });

        panel.appendChild(card);
      });
    })
    .catch(error => {
      console.error("Error de red o servidor al cargar favoritos:", error);
    });
}

///////////////////////////
// Aux UI
///////////////////////////
function obtenerCantidadDesdeInput() {
  const input = document.getElementById("codigo-barra");
  const entrada = input?.value.trim() || "";
  let cantidad = 1;

  if (entrada.includes("*")) {
    const partes = entrada.split("*").map(x => x.trim());
    const cantidadStr = partes[0];
    const parsed = parseInt(cantidadStr, 10);
    if (Number.isFinite(parsed) && parsed > 0) cantidad = parsed;
  }
  if (input) input.value = "";
  return cantidad;
}

function mostrarToast(mensaje) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.innerText = mensaje;
  toast.style.opacity = "1";
  toast.style.bottom = "20px";
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.bottom = "10px";
  }, 2500);
}

///////////////////////////
// Limpieza post-venta (única)
///////////////////////////
function limpiarCamposPostVenta() {
  // Vaciar carrito (misma referencia global)
  carrito.length = 0;

  // Si existe un UI manager alternativo, limpialo también
  try {
    if (window.CartUI && typeof CartUI.clear === 'function') CartUI.clear();
  } catch (_) {}

  // Re-render para borrar filas y totales
  renderizarCarrito();

  // Limpiar entradas comunes
  ['#codigo-barra', '#input-guarani', '#input-real', '#input-dolar'].forEach(sel => {
    const el = document.querySelector(sel);
    if (el) el.value = '';
  });

  // Foco para seguir vendiendo
  (document.getElementById('codigo-barra') || document.querySelector('input[type=search]'))?.focus();
}

// Hook desde venta_flow.js: dispatchEvent(new CustomEvent('venta:ok',{detail:{id_venta}}))
window.addEventListener('venta:ok', () => limpiarCamposPostVenta());

///////////////////////////
// Exponer en window
///////////////////////////
window.renderizarCarrito      = renderizarCarrito;
window.removerDelCarrito      = removerDelCarrito;
window.agregarAlCarrito       = agregarAlCarrito;
window.cargarFavoritos        = cargarFavoritos;
window.quitarFavorito         = function quitarFavorito(id_pro){
  if (!confirm("¿Deseás quitar este producto de tus favoritos?")) return;
  fetch("actualizar_favorito.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id_pro, favorito: false })
  })
  .then(res => res.json())
  .then(data => {
    if (data?.success) {
      alert("Producto eliminado de favoritos.");
      cargarFavoritos();
    } else {
      alert("No se pudo quitar de favoritos.");
    }
  })
  .catch(err => console.error("Error al quitar favorito:", err));
};
window.limpiarCarrito         = limpiarCamposPostVenta;
window.limpiarCamposPostVenta = limpiarCamposPostVenta;

///////////////////////////
// Selector de Precios (P1/P2/P3) — solo afecta al PRÓXIMO ítem
///////////////////////////
(function initPriceSelector(){
  if (typeof window.precioSeleccionado !== 'string') window.precioSeleccionado = 'p1';

  function marcarActivo(btn){
    ['btnPrecio1','btnPrecio2','btnPrecio3'].forEach(id => {
      const el = document.getElementById(id); if (el) el.classList.remove('activo');
    });
    btn?.classList.add('activo');
  }

  function bindPrecioBtn(id, nivel){ // 'p1' | 'p2' | 'p3'
    const btn = document.getElementById(id);
    if (!btn || btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      window.precioSeleccionado = nivel; // solo para PRÓXIMO agregado
      marcarActivo(btn);
      // No tocar líneas existentes ni forzar re-render aquí.
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    bindPrecioBtn('btnPrecio1','p1');
    bindPrecioBtn('btnPrecio2','p2');
    bindPrecioBtn('btnPrecio3','p3');
    marcarActivo(document.getElementById('btnPrecio1'));
  });
})();

///////////////////////////
// Boot
///////////////////////////
document.addEventListener('DOMContentLoaded', () => {
  renderizarCarrito();
  // si no querés cargar favoritos al abrir, comentá la línea de abajo
  cargarFavoritos();
});
