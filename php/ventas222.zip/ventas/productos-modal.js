(() => {
  const $  = (s, c=document)=> c.querySelector(s);
  const $$ = (s, c=document)=> Array.from(c.querySelectorAll(s));

  const MODAL   = '#modal-productos';
  const T_BODY  = '#mp-tabla tbody';
  const INPUT   = '#mp-buscar';

  let productos = [];
  let filtrados = [];
  let loaded = false;
  let selIndex = -1;

  const precioKey = ()=> (window.precioSeleccionado || 'precio1_pro');
  const num = (v)=> Number(v ?? 0);
  const fmtGs = (n)=> '₲ ' + Number(n||0).toLocaleString('es-PY', { maximumFractionDigits: 0 });

  async function ensureData(){
    if (loaded) return;
    const resp = await fetch('listar_productos.php', { headers: { 'Accept':'application/json' }});
    const js = await resp.json();
    if (!js?.success) throw new Error(js?.error || 'No se pudo cargar productos');
    productos = Array.isArray(js.data) ? js.data : [];
    loaded = true;
  }

  function filtrar(q){
    q = (q||'').trim().toLowerCase();
    if (!q){ filtrados = productos.slice(0, 500); return; }
    filtrados = productos.filter(p=>{
      const cod = String(p.codigo_barra_pro||'').toLowerCase();
      const nom = String(p.nombre_pro||'').toLowerCase();
      return cod.includes(q) || nom.includes(q);
    }).slice(0, 500);
  }

  function render(){
    const tbody = $(T_BODY);
    if (!tbody) return;
    tbody.innerHTML = '';

    filtrados.forEach((p, i)=>{
      const tr = document.createElement('tr');
      tr.tabIndex = 0; tr.dataset.idx = String(i);

      const p1 = num(p?.precio1_pro);
      const p2 = num(p?.precio2_pro);
      const p3 = num(p?.precio3_pro);
      const st = num(p?.cantidad_uni_pro ?? p?.stock ?? p?.stock_pro);

      const preciosHTML = `
        <div class="mp-precios">
          <button type="button" class="mp-add-tier" data-tier="precio1_pro">P1 · ${fmtGs(p1)}</button>
          <button type="button" class="mp-add-tier" data-tier="precio2_pro">P2 · ${fmtGs(p2)}</button>
          <button type="button" class="mp-add-tier" data-tier="precio3_pro">P3 · ${fmtGs(p3)}</button>
        </div>`;

      tr.innerHTML = `
        <td>${(p.codigo_barra_pro ?? '').toString()}</td>
        <td>${(p.nombre_pro ?? '').toString()}</td>
        <td style="text-align:right">${preciosHTML}</td>
        <td style="text-align:right">${st}</td>
      `;

      tbody.appendChild(tr);
    });

    selIndex = filtrados.length ? 0 : -1;
    paintActive();
  }

  function paintActive(){
    $$(T_BODY+' tr').forEach((tr, idx)=> tr.classList.toggle('row-active', idx === selIndex));
  }

  function openModal(){
    const m = $(MODAL);
    if (!m) { console.error('No existe #modal-productos'); return; }
    m.classList.remove('hidden');
    m.setAttribute('aria-hidden','false');
    setTimeout(()=> $(INPUT)?.focus(), 0);
  }
  function closeModal(){
    const m = $(MODAL);
    if (!m) return;
    m.classList.add('hidden');
    m.setAttribute('aria-hidden','true');
  }
  window.openModalProductos = openModal; // por si querés abrir manualmente

  function agregarConTier(p, tierKey){
    const precio = num(p?.[tierKey] ?? p?.precio1_pro);
    if (typeof window.agregarAlCarrito === 'function') {
      const item = { ...p, precio };
      window.agregarAlCarrito(item, 1);
    } else {
      alert(`Agregado: ${p?.nombre_pro} a ${fmtGs(precio)}`);
    }
  }
  function addSelectedAndClose(){
    if (selIndex < 0 || selIndex >= filtrados.length) return;
    const p = filtrados[selIndex];
    agregarConTier(p, precioKey());
    closeModal();
  }

  // Delegación global (no falla aunque el botón se monte después)
  document.addEventListener('click', (e)=>{
    // abrir modal
    if (e.target?.id === 'btn-abrir-lista'){
      ensureData().then(()=>{ filtrar(''); render(); openModal(); })
                  .catch(err=>{ console.error(err); alert('No se pudo cargar productos'); });
      return;
    }
    // cerrar modal (botón X o click fuera)
    if (e.target?.id === 'mp-cerrar') { closeModal(); return; }
    const modal = e.target.closest(MODAL);
    if (modal && !e.target.closest('.modal-content, .mp-content')) { closeModal(); return; }

    // agregar con P1/P2/P3
    const tierBtn = e.target.closest('.mp-add-tier');
    if (tierBtn) {
      const tr = e.target.closest('tr[data-idx]');
      if (!tr) return;
      const p = filtrados[Number(tr.dataset.idx)];
      agregarConTier(p, tierBtn.dataset.tier);
      closeModal();
      return;
    }

    // click en fila = agregar con precio global
    const row = e.target.closest('tr[data-idx]');
    if (row && e.target.tagName !== 'BUTTON'){
      selIndex = Number(row.dataset.idx || -1);
      addSelectedAndClose();
    }
  });

  // Teclado dentro del modal
  document.addEventListener('keydown', (e)=>{
    const visible = !$(MODAL)?.classList.contains('hidden');
    if (!visible) return;

    if (e.key === 'Escape'){ e.preventDefault(); closeModal(); return; }

    const rows = $$(T_BODY+' tr'); if (!rows.length) return;

    if (e.key === 'ArrowDown'){ e.preventDefault(); selIndex = Math.min(selIndex+1, rows.length-1); paintActive(); rows[selIndex]?.scrollIntoView({block:'nearest'}); }
    else if (e.key === 'ArrowUp'){ e.preventDefault(); selIndex = Math.max(selIndex-1, 0); paintActive(); rows[selIndex]?.scrollIntoView({block:'nearest'}); }
    else if (e.key === 'Enter'){ e.preventDefault(); addSelectedAndClose(); }
  });

  // Filtro
  document.addEventListener('input', (e)=>{
    if (e.target?.id === 'mp-buscar'){
      filtrar(e.target.value);
      render();
    }
  });

})();