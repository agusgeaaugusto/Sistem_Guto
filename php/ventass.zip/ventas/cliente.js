// =======================
// CLIENTE: buscar por RUC/CI, abrir modal si no existe, registrar y autocompletar
// =======================
(function () {
  'use strict';
  if (window.__clienteWiredV2) return; // evita doble wiring
  window.__clienteWiredV2 = true;

  const $ = (sel) => document.querySelector(sel);

  const MODAL_SEL = '#modal-nuevo-cliente';
  const CONTENT_SEL = '.modal-content, .nc-content, .mp-content'; // soporta nombres variados

  const showErr = (msg) => {
    if (typeof Swal !== 'undefined' && Swal?.fire) {
      Swal.fire({ title: 'Cliente', text: msg, icon: 'error' });
    } else {
      alert(msg);
    }
  };

  const showInfo = (msg) => {
    if (typeof Swal !== 'undefined' && Swal?.fire) {
      Swal.fire({ title: 'Cliente', text: msg, icon: 'info' });
    } else {
      alert(msg);
    }
  };

  // --- Modal helpers ---
  function openClienteModal(rucInicial = '') {
    const m = $(MODAL_SEL);
    if (!m) return console.warn('[Cliente] Modal no encontrado');
    m.classList.remove('hidden');
    m.setAttribute('aria-hidden', 'false');

    const inRuc = $('#nc-ruc');
    const inNom = $('#nc-nombre');
    if (inRuc) inRuc.value = rucInicial || '';
    if (inNom) inNom.value = '';

    setTimeout(() => inNom?.focus(), 0);
  }

  function closeClienteModal() {
    const m = $(MODAL_SEL);
    if (!m) return;
    m.classList.add('hidden');
    m.setAttribute('aria-hidden', 'true');
  }

  function isModalVisible() {
    const m = $(MODAL_SEL);
    return !!m && !m.classList.contains('hidden') && m.getAttribute('aria-hidden') !== 'true';
  }

  // Click afuera + Escape para cerrar (sin romper si no existe modal)
  document.addEventListener('click', (e) => {
    if (!isModalVisible()) return;
    const m = $(MODAL_SEL);
    if (!m || !m.contains(e.target)) return;

    const inContent = e.target.closest(CONTENT_SEL);
    if (!inContent) closeClienteModal();
  });

  document.addEventListener('keydown', (e) => {
    if (!isModalVisible()) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      closeClienteModal();
      $('#cliente-ruc')?.focus();
    }
  });

  // --- Normalizador de claves (acepta tus nombres de Postgres) ---
  function normalizePersona(p) {
    if (!p) return null;

    const id =
      p.id ?? p.id_persona ?? p.persona_id ?? p.idcliente ?? p.id_per ?? p.id_cli ?? p.idCliente ?? null;

    const ruc =
      p.ruc ?? p.ruc_ci ?? p.documento ?? p.ci ?? p.doc ?? p.cedula_per ?? p.ruc_per ?? '';

    const nombre =
      p.nombre ?? p.razon_social ?? p.apellido_nombre ?? p.denominacion ?? p.nombre_per ?? p.razon ?? '';

    return {
      id: id != null ? String(id) : '',
      ruc: String(ruc || '').trim(),
      nombre: String(nombre || '').trim()
    };
  }

  // --- Set UI ---
  function setClienteEnVenta(persona) {
    const n = normalizePersona(persona);
    if (!n) return;

    const rucEl = $('#cliente-ruc');
    const nomEl = $('#cliente-nombre');
    const idEl = $('#cliente-id');

    if (rucEl) {
      rucEl.value = n.ruc || '';
      rucEl.dataset.loadedDoc = n.ruc || '';
    }
    if (nomEl) nomEl.value = n.nombre || '';
    if (idEl) idEl.value = n.id || '';

    if (typeof window.onClienteSeleccionado === 'function') {
      try { window.onClienteSeleccionado(n); } catch (_) {}
    }
  }

  // Limpia nombre/id si cambian el RUC manualmente (pero sin borrarte a cada tecla “por deporte”)
  function wireCleanOnRucChange() {
    const rucEl = $('#cliente-ruc');
    if (!rucEl) return;

    let lastVal = rucEl.value.trim();

    rucEl.addEventListener('input', () => {
      const cur = rucEl.value.trim();
      if (cur === lastVal) return;

      // si el usuario cambia el doc, marcamos como "desincronizado"
      const loaded = rucEl.dataset.loadedDoc || '';
      if (cur !== loaded) {
        const nomEl = $('#cliente-nombre');
        const idEl = $('#cliente-id');
        if (nomEl) nomEl.value = '';
        if (idEl) idEl.value = '';
      }

      lastVal = cur;
    });
  }

  // --- Fetch API helpers (robustos) ---
  async function apiGet(url, signal) {
    const r = await fetch(url, { signal, headers: { 'Accept': 'application/json' }, cache: 'no-store' });
    const ct = (r.headers.get('content-type') || '').toLowerCase();
    const raw = await r.text();

    let data = null;
    if (ct.includes('application/json')) {
      try { data = JSON.parse(raw); } catch (_) {}
    } else {
      // a veces PHP manda JSON con content-type mal
      try { data = JSON.parse(raw); } catch (_) {}
    }

    return { ok: r.ok, data, status: r.status, raw };
  }

  async function apiPostForm(url, formData, signal) {
    const r = await fetch(url, { method: 'POST', body: formData, signal });
    const ct = (r.headers.get('content-type') || '').toLowerCase();
    const raw = await r.text();

    let data = null;
    if (ct.includes('application/json')) {
      try { data = JSON.parse(raw); } catch (_) {}
    } else {
      try { data = JSON.parse(raw); } catch (_) {}
    }

    return { ok: r.ok, data, status: r.status, raw };
  }

  // --- API dominio ---
  let lastController = null;

  async function fetchPersonaByDoc(doc) {
    // cancela búsquedas anteriores
    try { lastController?.abort(); } catch (_) {}
    lastController = new AbortController();

    const cleanDoc = String(doc || '').trim();
    if (!cleanDoc) return null;

    // intenta ?doc= ?ruc= ?ci=
    for (const qp of ['doc', 'ruc', 'ci']) {
      const r = await apiGet(`get_persona.php?${qp}=${encodeURIComponent(cleanDoc)}`, lastController.signal);

      if (!r.ok) continue;

      const d = r.data;

      // Formato recomendado: {success:true/false, data:{...}}
      if (d && d.success && (d.data || d.persona)) return normalizePersona(d.data || d.persona);

      // Soporte: responde directo {id_per,...}
      if (d && (d.id_per || d.id || d.id_persona)) return normalizePersona(d);

      // Si vino HTML/Warning
      if (!d && r.raw) {
        console.error('[Cliente] Respuesta cruda:', r.raw);
        throw new Error('Respuesta inválida del servidor (no es JSON).');
      }
    }

    return null;
  }

  async function registrarNuevoCliente(ruc, nombre) {
    const fd = new FormData();

    // Mandamos varios nombres de campos para compatibilidad con tu PHP
    fd.append('ruc', ruc);
    fd.append('nombre', nombre);
    fd.append('ruc_ci', ruc);
    fd.append('razon_social', nombre);
    fd.append('nombre_per', nombre);

    const r = await apiPostForm('register_persona_bi.php', fd);

    if (!r.ok) {
      // si vino HTML/Warning
      if (!r.data && r.raw) {
        console.error('[Cliente] Respuesta cruda register:', r.raw);
        throw new Error('Error del servidor al registrar (no es JSON).');
      }
      throw new Error(`No se pudo registrar (HTTP ${r.status})`);
    }

    const d = r.data;

    if (d?.success || d?.ok) {
      const persona = d.data || d.persona || d.cliente || { id: d.id, ruc, nombre };
      return normalizePersona(persona);
    }

    throw new Error(d?.message || d?.msg || 'No se pudo registrar el cliente.');
  }

  // --- Flow principal ---
  let _buscando = false;
  let _blurTimer = null;

  async function onClienteDocEnter() {
    const rucEl = $('#cliente-ruc');
    const doc = rucEl?.value.trim();
    if (!doc) return;

    const persona = await fetchPersonaByDoc(doc);
    if (persona) {
      setClienteEnVenta(persona);
    } else {
      openClienteModal(doc);
      showInfo('Cliente no encontrado. Registralo en el formulario.');
    }
  }

  async function safeBuscar() {
    if (_buscando) return;
    _buscando = true;
    try {
      await onClienteDocEnter();
    } catch (err) {
      console.error(err);
      showErr(err?.message || 'Error al buscar cliente.');
    } finally {
      _buscando = false;
    }
  }

  const isEnter = (e) => (e.key === 'Enter' || e.key === 'NumpadEnter' || e.keyCode === 13);

  // --- Wiring ---
  document.addEventListener('DOMContentLoaded', () => {
    const inDoc = $('#cliente-ruc');
    if (!inDoc) { console.warn('[Cliente] #cliente-ruc no encontrado'); return; }

    wireCleanOnRucChange();

    // Submit del form
    const form = inDoc.closest('form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        e.stopPropagation();
        safeBuscar();
      }, true);
    }

    // Enter en captura: evita que otros scripts lo roben
    inDoc.addEventListener('keydown', (e) => {
      if (isEnter(e)) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        safeBuscar();
      }
    }, true);

    // Blur con debounce (evita doble búsqueda)
    inDoc.addEventListener('blur', () => {
      if (_blurTimer) clearTimeout(_blurTimer);
      _blurTimer = setTimeout(() => {
        if (inDoc.value.trim()) safeBuscar();
      }, 120);
    });

    // Modal cancelar
    $('#nc-cancelar')?.addEventListener('click', () => {
      closeClienteModal();
      $('#cliente-ruc')?.focus();
    });

    // Modal guardar
    $('#form-nuevo-cliente')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const ruc = $('#nc-ruc')?.value.trim();
      const nombre = $('#nc-nombre')?.value.trim();
      if (!ruc || !nombre) return showErr('Completá RUC/C.I. y Nombre');

      try {
        const persona = await registrarNuevoCliente(ruc, nombre);
        setClienteEnVenta(persona);
        closeClienteModal();
        $('#cliente-ruc')?.focus();
      } catch (err) {
        console.error(err);
        showErr(err?.message || 'Error al registrar el cliente.');
      }
    });
  });

  // API pública opcional (debug)
  window.Cliente = { openClienteModal, closeClienteModal };
})();
