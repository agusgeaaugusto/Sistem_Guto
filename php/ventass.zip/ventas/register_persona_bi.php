<?php
header('Content-Type: application/json; charset=UTF-8');
require_once __DIR__ . '/conexion_bi.php';

$ruc    = trim($_POST['ruc']    ?? '');
$nombre = trim($_POST['nombre'] ?? '');
if ($ruc === '' || $nombre === '') { http_response_code(400); echo json_encode(['success'=>false,'message'=>'Faltan datos']); exit; }

$sel = pg_query_params($conexion, "SELECT id_per, nombre_per, cedula_per FROM persona WHERE cedula_per = $1 LIMIT 1", [$ruc]);
if ($sel && pg_num_rows($sel) > 0) {
  $row = pg_fetch_assoc($sel);
  echo json_encode(['success'=>true,'data'=>[
    'id_persona'=>$row['id_per'], 'ruc_ci'=>$row['cedula_per'], 'nombre'=>$row['nombre_per']
  ]]); pg_close($conexion); exit;
}

$ins = pg_query_params($conexion, "INSERT INTO persona (cedula_per, nombre_per) VALUES ($1, $2) RETURNING id_per, nombre_per, cedula_per", [$ruc, $nombre]);
if (!$ins) { http_response_code(500); echo json_encode(['success'=>false,'message'=>'No se pudo registrar']); pg_close($conexion); exit; }
$row = pg_fetch_assoc($ins);
echo json_encode(['success'=>true,'data'=>[
  'id_persona'=>$row['id_per'], 'ruc_ci'=>$row['cedula_per'], 'nombre'=>$row['nombre_per']
]]);
pg_close($conexion);
