<?php
// ventas.php - Carvallo Bodega (pantalla de ventas) - VERSIÓN OPTIMIZADA
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Carvallo Bodega - Pantalla de Ventas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="venta.css?v=20251220-3">
</head>

<body class="modern-ui shell-embed">
  <header class="appbar">
    <div class="brand">CARVALLO BODEGA</div>
    <nav class="top-actions">
      <button type="button" class="btn ghost">Inicio</button>
      <button type="button" class="btn ghost active">Ventas</button>
      <button type="button" class="btn danger-outline">Salir</button>
    </nav>
  </header>

  <main class="container">
    <div class="container-pantalla">
      <section class="left-panel card" aria-label="Datos y carrito">
        <div class="cliente-info">
  <label for="cliente-ruc">RUC / C.I.:</label>
  <input type="text" id="cliente-ruc" placeholder="4567890" />

  <label for="cliente-nombre">Nombre:</label>
  <input type="text" id="cliente-nombre" placeholder="Nombre del cliente" />

  <input type="hidden" id="cliente-id" name="cliente_id" />
</div>

<div class="contenedor-totales-cotizaciones">

  <!-- TOTAL -->
  <div class="total card-kpi">
    <h3>TOTAL</h3>
    <div class="fila-monedas">
      <div class="moneda grande">
        <img src="../img/productos/guarani.png" class="icono-moneda">
        <strong id="espejo-total-guarani">₲ 0</strong>
      </div>
      <div class="moneda">
        <img src="../img/productos/real.png" class="icono-moneda">
        <strong id="espejo-total-real">R$ 0,00</strong>
      </div>
      <div class="moneda">
        <img src="../img/productos/dolar.png" class="icono-moneda">
        <strong id="espejo-total-dolar">US$ 0,00</strong>
      </div>
    </div>
  </div>

  <!-- COTIZACIÓN -->
  <div class="cotizacion card-kpi">
    <h3>COTIZACIÓN</h3>
    <div class="fila-monedas">
      <div class="moneda">
        <img src="../img/productos/guarani.png" class="icono-moneda">
        <strong id="cotizacion-guarani">₲ 0</strong>
      </div>
      <div class="moneda">
        <img src="../img/productos/real.png" class="icono-moneda">
        <strong id="cotizacion-real">R$ 0</strong>
      </div>
      <div class="moneda">
        <img src="../img/productos/dolar.png" class="icono-moneda">
        <strong id="cotizacion-dolar">US$ 0</strong>
      </div>
    </div>
  </div>

</div>


        <div class="factura">
          <table class="carrito" data-role="carrito">
            <thead>
              <tr>
                <th class="table--truncate">Código</th>
                <th class="table--truncate" style="min-width: 140px;">Producto</th>
                <th class="text-center" style="width: 60px;">Cant.</th>
                <th class="num">Precio Unit.</th>
                <th class="num">Subtotal</th>
                <th style="width: 40px;"></th>
              </tr>
            </thead>
            <tbody id="tbody-carrito"></tbody>
          </table>
        </div>

        <div class="barra-accion-unificada">

  <!-- PRECIOS -->
  <div class="grupo-precios-mini">
    <button type="button" id="btnPrecio1" class="precio-btn activo">P1</button>
    <button type="button" id="btnPrecio2" class="precio-btn">P2</button>
    <button type="button" id="btnPrecio3" class="precio-btn">P3</button>
  </div>

  <!-- CÓDIGO DE BARRA -->
  <div class="input-grupo-compacto">
    <input type="text" id="codigo-barra" placeholder="Cód. Barra">
  </div>

  <!-- PRODUCTOS -->
  <button type="button" id="btn-abrir-lista" class="btn accent compact-btn btn-icon-text">
    <img src="../img/productos/productos.png" class="icon-btn" alt="">
    <span>Productos</span>
  </button>

  <!-- COBRAR -->
  <button type="button" id="btn-pagar-vender" class="btn green compact-btn btn-icon-text">
    <img src="../img/productos/cobrar.png" class="icon-btn" alt="">
    <span>Cobrar</span>
  </button>

</div>

        

      </section>

      <aside class="right-panel card" aria-label="Favoritos y cobro">
        <div class="rp-tabs">
          <button type="button" class="rp-tab active" data-target="panel-accesos">Acceso Rápido</button>
          <button type="button" class="rp-tab" data-target="panel-finalizar" id="tab-finalizar">Finalizar Venta</button>
        </div>

        <div class="rp-content" style="flex:1; overflow-y:auto;">
          <section id="panel-finalizar" hidden>
            <div class="resumen-pago card resumen-monedas">
  
  <div class="resumen-item">
    <div class="resumen-head">
      <img src="../img/productos/guarani.png" alt="Gs" class="resumen-icon">
      <span class="resumen-simbolo">₲</span>
    </div>
    <div class="resumen-valor" id="resta-guarani">0</div>
    <div class="resumen-sub">Falta</div>
  </div>

  <div class="resumen-item">
    <div class="resumen-head">
      <img src="../img/productos/real.png" alt="R$" class="resumen-icon">
      <span class="resumen-simbolo">R$</span>
    </div>
    <div class="resumen-valor" id="resta-real">0,00</div>
    <div class="resumen-sub">Falta</div>
  </div>

  <div class="resumen-item">
    <div class="resumen-head">
      <img src="../img/productos/dolar.png" alt="US$" class="resumen-icon">
      <span class="resumen-simbolo">US$</span>
    </div>
    <div class="resumen-valor" id="resta-dolar">0,00</div>
    <div class="resumen-sub">Falta</div>
  </div>

</div>
<div class="pagos-grid compact pagos-inline">

  <div class="pago pago-inline">
    <div class="moneda">
      <img src="../img/productos/guarani.png" alt="₲" class="pago-icon">
      <span class="pago-simbolo">₲</span>
    </div>
    <div class="campo-moneda">
      <input type="number" id="input-guarani" inputmode="numeric" step="1" min="0" placeholder="0">
    </div>
  </div>

  <div class="pago pago-inline">
    <div class="moneda">
      <img src="../img/productos/real.png" alt="R$" class="pago-icon">
      <span class="pago-simbolo">R$</span>
    </div>
    <div class="campo-moneda">
      <input type="number" id="input-real" inputmode="decimal" step="0.01" min="0" placeholder="0.00">
    </div>
  </div>

  <div class="pago pago-inline">
    <div class="moneda">
      <img src="../img/productos/dolar.png" alt="US$" class="pago-icon">
      <span class="pago-simbolo">US$</span>
    </div>
    <div class="campo-moneda">
      <input type="number" id="input-dolar" inputmode="decimal" step="0.01" min="0" placeholder="0.00">
    </div>
  </div>

</div>


            <div class="teclado-y-cobro" style="margin-top:12px; display:flex; gap:12px;">
              <div class="lado-derecho" style="flex:1;">
                <div class="teclado" id="teclado">
                  <button type="button" data-key="1">1</button><button type="button" data-key="2">2</button><button type="button" data-key="3">3</button>
                  <button type="button" data-key="4">4</button><button type="button" data-key="5">5</button><button type="button" data-key="6">6</button>
                  <button type="button" data-key="7">7</button><button type="button" data-key="8">8</button><button type="button" data-key="9">9</button>
                  <button type="button" data-key="0">0</button><button type="button" data-key=".">.</button><button type="button" data-key="BACK">←</button>
                </div>
                <div id="estado-pago" class="text-muted text-center mt-8"></div>
              </div>

              <div class="botones-cobro" style="flex:1; display:flex; flex-direction: column; gap:10px;">
                <button type="button" class="btn-cuadrado text-lg" id="btn-cobro-rapido">Cobro Rápido</button>
                <button type="button" class="btn-cuadrado ticket text-lg" id="btn-cobro-rapido-ticket">Ticket</button>

                <button
                  type="button"
                  id="btn-factura-legal"
                  class="btn-cuadrado f12 text-lg"
                  title="Imprimir Factura (F9)"
                >
                  Factura (F9)
                </button>

                <button type="button" class="btn gray" style="flex:1; height:48px;">Otros Pagos</button>
              </div>
            </div>
          </section>

          <section id="panel-accesos">
            <h3>Acceso Rápido</h3>
            <div class="product-grid" id="panelFavoritos" aria-live="polite">
              </div>
          </section>
        </div>
      </aside>
    </div>
  </main>

  <script src="precio_selector.js"></script>
  <script src="main.js"></script>
  <script src="carrito_y_favorito.js"></script>
  <script src="pagos.js"></script>
  <script src="calculadora.js"></script>
  <script src="cliente.js"></script>
  <script src="productos-modal.js"></script>
  <script src="venta_flow.js?v=20251028-7"></script>

  <script>
  window.addEventListener('DOMContentLoaded', () => {
    if (window.CartUI?.onChange && CartUI._fmt && CartUI._fromGs) {
      CartUI.onChange(({ subtotalGs }) => {
        const f = CartUI._fmt, conv = CartUI._fromGs;
        document.querySelector('#derecha-total-guarani')?.replaceChildren(document.createTextNode(f.fmtGs(conv.guarani(subtotalGs))));
        document.querySelector('#derecha-total-real')?.replaceChildren(document.createTextNode(f.fmtReal(conv.real(subtotalGs))));
        document.querySelector('#derecha-total-dolar')?.replaceChildren(document.createTextNode(f.fmtDolar(conv.dolar(subtotalGs))));
      });
    }
  });

  document.querySelectorAll('.rp-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.rp-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.rp-content section').forEach(sec => sec.hidden = true);
      const target = document.getElementById(btn.dataset.target);
      if (target) target.hidden = false;
    });
  });

  (() => {
    const hostSelector = 'button, .btn';
    document.addEventListener('click', (ev) => {
      const target = ev.target.closest(hostSelector);
      if (!target) return;
      target.classList.add('ripple-host');
      const rect = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      const size = Math.max(rect.width, rect.height);
      ripple.className = 'ripple';
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (ev.clientX - rect.left - size / 2) + 'px';
      ripple.style.top  = (ev.clientY - rect.top  - size / 2) + 'px';
      target.appendChild(ripple);
      ripple.addEventListener('animationend', () => ripple.remove());
    }, {capture:true});
  })();
  </script>
  <!-- ==========================
     MODAL PRODUCTOS (F4)
     ========================== -->
<div class="modal" id="modal-productos" aria-hidden="true">
  <div class="modal-backdrop" data-close="1"></div>

  <div class="modal-card" role="dialog" aria-modal="true" aria-label="Lista de productos">
    <div class="modal-head">
      <div class="modal-title">
        <img src="../img/productos/productos.png" class="modal-title-icon" alt="">
        <h3>Productos</h3>
      </div>

      <button type="button" class="btn btn-close" id="btn-cerrar-modal-productos" title="Cerrar (Esc)">
        ✕
      </button>
    </div>

    <div class="modal-tools">
      <input type="text" id="buscar-productos" placeholder="Buscar por nombre o código..." autocomplete="off">
      <button type="button" class="btn primary" id="btn-refrescar-productos" title="Actualizar lista">
        Actualizar
      </button>
    </div>

    <div class="modal-body">
      <div class="modal-grid" id="lista-productos" aria-live="polite"></div>
      <div class="modal-empty" id="productos-empty" hidden>No hay productos para mostrar.</div>
    </div>

    <div class="modal-foot">
      <small class="modal-hint">Atajos: <b>F4</b> abrir/cerrar · <b>Esc</b> cerrar · <b>Enter</b> agregar seleccionado</small>
    </div>
  </div>
</div>

</body>
</html>