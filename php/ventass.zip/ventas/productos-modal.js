(() => {
  const $ = (s, r=document) => r.querySelector(s);

  const modal = $('#modal-productos');
  const btnOpen = $('#btn-abrir-lista');
  const btnClose = $('#btn-cerrar-modal-productos');
  const backdrop = modal?.querySelector('.modal-backdrop');
  const inputBuscar = $('#buscar-productos');
  const btnRefresh = $('#btn-refrescar-productos');
  const grid = $('#lista-productos');
  const empty = $('#productos-empty');

  if (!modal || !btnOpen || !grid) return;

  let productos = [];
  let seleccionado = null;

  function openModal(){
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    setTimeout(() => inputBuscar?.focus(), 50);
  }
  function closeModal(){
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    seleccionado = null;
  }

  // ✅ CARGA: usa window.PRODUCTOS si existe; si no, intentá tu endpoint
  async function cargarProductos(){
    // 1) Si ya tenés un array global, úsalo
    if (Array.isArray(window.PRODUCTOS) && window.PRODUCTOS.length){
      productos = window.PRODUCTOS;
      render(productos);
      return;
    }

    // 2) Fallback: intentá endpoint (ajustá si tu ruta es otra)
    try{
      const res = await fetch('listar_productos.php', { cache:'no-store' });
      const data = await res.json();
      productos = Array.isArray(data) ? data : (data?.data || []);
      render(productos);
    }catch(e){
      productos = [];
      render(productos);
      console.warn('No se pudo cargar productos. Ajustá el endpoint listar_productos.php', e);
    }
  }

  function normalizarStr(s){
    return (s ?? '').toString().toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,'');
  }

  function filtrar(){
    const q = normalizarStr(inputBuscar?.value || '');
    if (!q) return render(productos);

    const out = productos.filter(p => {
      const nombre = normalizarStr(p.nombre || p.nombre_pro || p.descripcion || '');
      const codigo = normalizarStr(p.codigo || p.codigo_barra || p.codigo_barra_pro || '');
      return nombre.includes(q) || codigo.includes(q);
    });
    render(out);
  }

  function render(list){
    grid.innerHTML = '';
    if (!list || !list.length){
      empty.hidden = false;
      return;
    }
    empty.hidden = true;

    list.forEach(p => {
      const id = p.id || p.id_pro || p.producto_id;
      const nombre = p.nombre || p.nombre_pro || p.descripcion || 'Producto';
      const codigo = p.codigo || p.codigo_barra || p.codigo_barra_pro || '';
      const precio = p.precio1 || p.precio1_pro || p.precio || '';
      const img = p.imagen || p.img || p.foto || '../img/productos/noimg.png';

      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'prod-card';
      card.dataset.id = id;

      card.innerHTML = `
        <div class="prod-img"><img src="${img}" alt=""></div>
        <div class="prod-info">
          <div class="prod-name" title="${nombre}">${nombre}</div>
          <div class="prod-meta">
            <span>${codigo}</span>
            <span class="prod-price">${precio ? precio : ''}</span>
          </div>
        </div>
      `;

      card.addEventListener('click', () => {
        seleccionado = { ...p, _id: id };
        agregarAlCarrito(seleccionado);
      });

      grid.appendChild(card);
    });
  }

  function agregarAlCarrito(p){
    // 1) Si tenés CartUI
    if (window.CartUI && typeof window.CartUI.add === 'function'){
      window.CartUI.add(p);
      closeModal();
      return;
    }
    // 2) Si tenés una función propia
    if (typeof window.agregarAlCarrito === 'function'){
      window.agregarAlCarrito(p);
      closeModal();
      return;
    }
    // 3) Evento para que tu carrito lo atienda
    document.dispatchEvent(new CustomEvent('producto:agregar', { detail: p }));
    closeModal();
  }

  // Eventos UI
  btnOpen.addEventListener('click', openModal);
  btnClose?.addEventListener('click', closeModal);
  backdrop?.addEventListener('click', closeModal);
  btnRefresh?.addEventListener('click', cargarProductos);
  inputBuscar?.addEventListener('input', filtrar);

  // Atajos
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F4'){
      e.preventDefault();
      modal.classList.contains('is-open') ? closeModal() : openModal();
    }
    if (e.key === 'Escape' && modal.classList.contains('is-open')){
      e.preventDefault();
      closeModal();
    }
  });

  // Cargar una vez
  window.addEventListener('DOMContentLoaded', () => {
    cargarProductos();
  });
})();
