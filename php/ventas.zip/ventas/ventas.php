<?php
// ventas.php - Carvallo Bodega (pantalla de ventas) - VERSIÓN LIMPIA
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Carvallo Bodega - Pantalla de Ventas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- Forzar cache-busting del CSS -->
  <link rel="stylesheet" href="venta.css?v=20251028-1" />
</head>

<body class="modern-ui shell-embed">
  <header class="appbar">
    <div class="brand">CARVALLO BODEGA</div>
    <nav class="top-actions">
      <button type="button" class="btn ghost">Inicio</button>
      <button type="button" class="btn ghost active">Ventas</button>
      <button type="button" class="btn danger-outline">Salir</button>
    </nav>
  </header>

  <main class="container">
    <div class="container-pantalla">
      <!-- ====== PANEL IZQUIERDO ====== -->
      <section class="left-panel card" aria-label="Datos y carrito">
        <!-- Cliente -->
        <div class="cliente-info">
          <label for="cliente-ruc">RUC / C.I.:</label>
          <input type="text" id="cliente-ruc" placeholder="Ej: 4567890" />
          <label for="cliente-nombre">Nombre:</label>
          <input type="text" id="cliente-nombre" placeholder="Nombre del cliente" />
          <input type="hidden" id="cliente-id" name="cliente_id" />
        </div>

        <div id="cliente-visor" class="cliente-visor mb-8" aria-live="polite">
          CONSUMIDOR FINAL (s/RUC)
        </div>

        <!-- Totales y cotización -->
        <div class="contenedor-totales-cotizaciones horizontal mb-12">
          <div class="total card-kpi">
            <h3 class="text-sm">TOTAL</h3>
            <div class="fila-monedas">
              <div class="moneda grande">
                <img src="../img/productos/guarani.png" alt="Guaraní" class="icono-moneda">
                <strong id="espejo-total-guarani">₲ 0</strong>
              </div>
              <div class="moneda">
                <img src="../img/productos/real.png" alt="Real" class="icono-moneda">
                <strong id="espejo-total-real">R$ 0,00</strong>
              </div>
              <div class="moneda">
                <img src="../img/productos/dolar.png" alt="Dólar" class="icono-moneda">
                <strong id="espejo-total-dolar">US$ 0,00</strong>
              </div>
            </div>
          </div>

          <div class="cotizacion card-kpi">
            <h3 class="text-sm">COTIZACIÓN (REF.)</h3>
            <div class="fila-monedas small">
              <div class="moneda">
                <img src="../img/productos/guarani.png" alt="Guaraní" class="icono-moneda">
                <strong id="cotizacion-guarani">₲ 0</strong>
              </div>
              <div class="moneda">
                <img src="../img/productos/real.png" alt="Real" class="icono-moneda">
                <strong id="cotizacion-real">R$ 0</strong>
              </div>
              <div class="moneda">
                <img src="../img/productos/dolar.png" alt="Dólar" class="icono-moneda">
                <strong id="cotizacion-dolar">US$ 0</strong>
              </div>
            </div>
          </div>
        </div>

        <!-- Carrito -->
        <div class="factura">
          <table class="carrito" data-role="carrito">
            <thead>
              <tr>
                <th class="table--truncate">Código</th>
                <th class="table--truncate" style="min-width: 140px;">Producto</th>
                <th class="text-center" style="width: 60px;">Cant.</th>
                <th class="num">Precio Unit.</th>
                <th class="num">Subtotal</th>
                <th style="width: 40px;"></th>
              </tr>
            </thead>
            <tbody id="tbody-carrito"></tbody>
          </table>
        </div>

        <!-- Buscador + Lista -->
        <div class="row gap-8 mt-12 mb-8" style="align-items: stretch;">
          <div class="buscador-codigo" style="flex:1;">
            <input type="text" id="codigo-barra" placeholder="Escanear o ingresar código de barra" />
            <button type="button" id="btn-buscar-producto" class="btn btn-primary" style="padding: 10px 12px;">
              <span class="text-sm">Adicionar</span>
            </button>
          </div>
          <button type="button" id="btn-abrir-lista" class="btn accent" style="padding: 0 14px;">Lista (F4)</button>
        </div>

        <!-- Acciones inferiores -->
        <div class="bottom-buttons">
          <button type="button" class="btn red" id="btn-remover-item">Remover</button>
          <button type="button" id="btn-pagar-vender" class="btn green text-lg">💵 Finalizar Venta</button>
          <div class="grupo-precios">
            <button type="button" id="btnPrecio1" class="precio-btn activo">P1</button>
            <button type="button" id="btnPrecio2" class="precio-btn">P2</button>
            <button type="button" id="btnPrecio3" class="precio-btn">P3</button>
          </div>
        </div>
      </section>

      <!-- ====== PANEL DERECHO ====== -->
      <aside class="right-panel card" aria-label="Favoritos y cobro">
        <div class="rp-tabs">
          <button type="button" class="rp-tab active" data-target="panel-accesos">Acceso Rápido</button>
          <button type="button" class="rp-tab" data-target="panel-finalizar" id="tab-finalizar">Finalizar Venta</button>
        </div>

        <div class="rp-content" style="flex:1; overflow-y:auto;">
          <!-- Finalizar -->
          <section id="panel-finalizar" hidden>
            <div class="resumen-pago card" style="margin-bottom:12px;">
              <div class="fila-resumen"><strong>Total Gs:</strong> <span id="derecha-total-guarani">₲ 0</span></div>
              <div class="fila-resumen"><strong>Total R$:</strong> <span id="derecha-total-real">R$ 0,00</span></div>
              <div class="fila-resumen"><strong>Total US$:</strong> <span id="derecha-total-dolar">US$ 0,00</span></div>
            </div>

            <div class="pagos-grid compact">
              <div class="pago">
                <div class="moneda">
                  <img src="../img/productos/guarani.png" alt="₲" style="width:20px;height:20px;border-radius:4px;">
                  <small id="resta-guarani" class="estado-moneda">Falta: ₲ 0</small>
                </div>
                <div class="campo-moneda">
                  <input type="number" id="input-guarani" inputmode="numeric" step="1" min="0" placeholder="0" />
                </div>
              </div>

              <div class="pago">
                <div class="moneda">
                  <img src="../img/productos/real.png" alt="R$" style="width:20px;height:20px;border-radius:4px;">
                  <small id="resta-real" class="estado-moneda">Falta: R$ 0,00</small>
                </div>
                <div class="campo-moneda">
                  <input type="number" id="input-real" inputmode="decimal" step="0.01" min="0" placeholder="0.00" />
                </div>
              </div>

              <div class="pago">
                <div class="moneda">
                  <img src="../img/productos/dolar.png" alt="US$" style="width:20px;height:20px;border-radius:4px;">
                  <small id="resta-dolar" class="estado-moneda">Falta: US$ 0,00</small>
                </div>
                <div class="campo-moneda">
                  <input type="number" id="input-dolar" inputmode="decimal" step="0.01" min="0" placeholder="0.00" />
                </div>
              </div>
            </div>

            <div class="teclado-y-cobro" style="margin-top:12px; display:flex; gap:12px;">
              <div class="lado-derecho" style="flex:1;">
                <div class="teclado" id="teclado">
                  <button type="button" data-key="1">1</button><button type="button" data-key="2">2</button><button type="button" data-key="3">3</button>
                  <button type="button" data-key="4">4</button><button type="button" data-key="5">5</button><button type="button" data-key="6">6</button>
                  <button type="button" data-key="7">7</button><button type="button" data-key="8">8</button><button type="button" data-key="9">9</button>
                  <button type="button" data-key="0">0</button><button type="button" data-key=".">.</button><button type="button" data-key="BACK">←</button>
                </div>
                <div id="estado-pago" class="text-muted text-center mt-8"></div>
              </div>

              <div class="botones-cobro" style="flex:1; display:flex; flex-direction: column; gap:10px;">
                <button type="button" class="btn-cuadrado text-lg" id="btn-cobro-rapido">Cobro Rápido</button>
                <button type="button" class="btn-cuadrado ticket text-lg" id="btn-cobro-rapido-ticket">Ticket</button>

                <!-- Botón Factura (sin onclick, se enlaza por JS) -->
                <button
                  type="button"
                  id="btn-factura-legal"
                  class="btn-cuadrado f12 text-lg"
                  title="Imprimir Factura (F9)"
                >
                  Factura (F9)
                </button>

                <button type="button" class="btn gray" style="flex:1; height:48px;">Otros Pagos</button>
              </div>
            </div>
          </section>

          <!-- Accesos rápidos / Favoritos -->
          <section id="panel-accesos">
            <h3>Acceso Rápido</h3>
            <div class="product-grid" id="panelFavoritos" aria-live="polite">
              <button type="button" class="add-card" id="btnAbrirModalFavorito" title="Agregar acceso rápido">+</button>
              <!-- Tarjetas por JS -->
            </div>
          </section>
        </div>
      </aside>
    </div>
  </main>

  <!-- ====== SCRIPTS ====== -->
  <script src="precio_selector.js"></script>
  <script src="main.js"></script>
  <script src="carrito_y_favorito.js"></script>
  <script src="pagos.js"></script>
  <script src="calculadora.js"></script>
  <script src="cliente.js"></script>
  <script src="productos-modal.js"></script>

  <!-- Tu flujo único (el bueno). VERSIONA para romper caché -->
  <script src="venta_flow.js?v=20251028-7"></script>

  <!-- Sincroniza totales de la derecha si existe CartUI -->
  <script>
  window.addEventListener('DOMContentLoaded', () => {
    if (window.CartUI?.onChange && CartUI._fmt && CartUI._fromGs) {
      CartUI.onChange(({ subtotalGs }) => {
        const f = CartUI._fmt, conv = CartUI._fromGs;
        document.querySelector('#derecha-total-guarani')?.replaceChildren(document.createTextNode(f.fmtGs(conv.guarani(subtotalGs))));
        document.querySelector('#derecha-total-real')?.replaceChildren(document.createTextNode(f.fmtReal(conv.real(subtotalGs))));
        document.querySelector('#derecha-total-dolar')?.replaceChildren(document.createTextNode(f.fmtDolar(conv.dolar(subtotalGs))));
      });
    }
  });
  </script>

  <!-- Tabs -->
  <script>
  document.querySelectorAll('.rp-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.rp-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.rp-content section').forEach(sec => sec.hidden = true);
      const target = document.getElementById(btn.dataset.target);
      if (target) target.hidden = false;
    });
  });
  </script>

  <!-- Ripple visual minimalista -->
  <script>
  (() => {
    const hostSelector = 'button, .btn';
    document.addEventListener('click', (ev) => {
      const target = ev.target.closest(hostSelector);
      if (!target) return;
      target.classList.add('ripple-host');
      const rect = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      const size = Math.max(rect.width, rect.height);
      ripple.className = 'ripple';
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (ev.clientX - rect.left - size / 2) + 'px';
      ripple.style.top  = (ev.clientY - rect.top  - size / 2) + 'px';
      target.appendChild(ripple);
      ripple.addEventListener('animationend', () => ripple.remove());
    }, {capture:true});
  })();
  </script>
</body>
</html>
