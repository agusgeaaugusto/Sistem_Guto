// === venta_helpers.js (mejorado) ===
function $(sel, ctx=document){ return ctx.querySelector(sel); }
function $all(sel, ctx=document){ return Array.from(ctx.querySelectorAll(sel)); }
function parseNumber(txt, def=0){ if (txt==null) return def; if (typeof txt==='number') return isFinite(txt)?txt:def; const s=String(txt).replace(/\./g,'').replace(',', '.').replace(/[^\d.-]/g,'').trim(); const n=parseFloat(s); return isFinite(n)?n:def; }
function parseItemsFromDOM(){
  const table = $('#tabla-carrito') || $('#tabla-venta') || $('.tabla-carrito') || $('.tabla-venta') || $('table#venta-items') || $('table#carrito');
  if (!table) return null;
  const rows = $all('tbody tr', table), items=[];
  for (const tr of rows){
    const id = parseInt(tr.dataset.id_pro || tr.dataset.id || tr.getAttribute('data-id') || 0);
    const nombre = tr.dataset.nombre || $('.nombre', tr)?.textContent?.trim() || tr.querySelector('td:nth-child(2)')?.textContent?.trim() || '';
    const iCant = $('.cant, input.cant, input[name="cantidad"]', tr) || tr.querySelector('td:nth-child(3) input');
    const cant = parseNumber(iCant?.value ?? iCant?.textContent ?? 1, 1);
    const precioEl = $('.precio, input.precio', tr) || tr.querySelector('td:nth-child(4)') || tr.querySelector('td:nth-child(4) input');
    const precio = parseNumber(precioEl?.value ?? precioEl?.textContent ?? 0, 0);
    const subtotal = +(cant*precio).toFixed(2);
    if (cant>0 && (precio>=0)) items.push({ id_pro: id || parseInt(tr.dataset.id_producto || 0), nombre_pro: nombre, cantidad: cant, precio_unit: precio, subtotal });
  }
  return items.length ? items : null;
}
function normalizarItems(items){ return (items||[]).map(it=>{ const id_pro = parseInt(it.id_pro ?? it.id_producto ?? 0); const cantidad = parseNumber(it.cantidad ?? 0, 0); const precio_unit = parseNumber(it.precio_unit ?? it.precio ?? 0, 0); const subtotal = it.subtotal != null ? parseNumber(it.subtotal, 0) : +(cantidad*precio_unit).toFixed(2); const nombre = it.nombre_pro ?? it.descripcion ?? it.nombre ?? ''; return { id_pro, nombre_pro: nombre, cantidad, precio_unit, subtotal }; }).filter(it=> it.cantidad>0 && (it.id_pro>0 || it.nombre_pro)); }
window.carrito = Array.isArray(window.carrito) ? window.carrito : [];
function renderCarrito(){}
function actualizarTotales(total=0, desc=0, vuelto=0){}
function limpiarCarritoUI(){
  try{ window.carrito = []; localStorage.removeItem('carrito'); }catch(e){}
  ['inp-recibido','inp-vuelto','inp-descuento','inp-total','inp-observacion'].forEach(id=>{ const el=document.getElementById(id); if(el){ el.value = (id==='inp-total')?'0':''; }});
  const table = document.querySelector('#tabla-carrito, #tabla-venta, .tabla-carrito, .tabla-venta, table#venta-items, table#carrito');
  if (table){ const tb=table.tBodies && table.tBodies[0]; if (tb) tb.innerHTML=''; }
  actualizarTotales(0,0,0); if (typeof renderCarrito==='function') renderCarrito();
}
function buildPayloadFromUI(){
  const domItems = parseItemsFromDOM();
  const items = normalizarItems(domItems || window.carrito);
  const read=(id,def=0)=>parseNumber(document.getElementById(id)?.value ?? def, def);
  return { items, descuento: read('inp-descuento',0), total: read('inp-total',0), pago:{ recibido: read('inp-recibido',0), vuelto: read('inp-vuelto',0) }, observacion: document.getElementById('inp-observacion')?.value || '', estado_venta:'CER' };
}
async function guardarVenta(payloadOpt){
  const payload = payloadOpt || buildPayloadFromUI();
  const snapshot = JSON.parse(JSON.stringify(payload));
  const res = await fetch('guardar_venta.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const json = await res.json(); if(!res.ok||!json.ok) throw new Error(json.msg||'Error al guardar la venta');
  limpiarCarritoUI();
  const desea = (typeof Swal!=='undefined' && Swal?.fire)? await Swal.fire({title:'Venta guardada',text:`Factura #${json.nrofactura}. ¿Previsualizar?`,icon:'success',showCancelButton:true,confirmButtonText:'Sí',cancelButtonText:'No'}).then(r=>r.isConfirmed) : confirm(`Venta OK. Factura #${json.nrofactura}. ¿Previsualizar ahora?`);
  if(desea && typeof abrirPreviewFactura==='function'){ abrirPreviewFactura({id_venta:json.id_venta,nrofactura:json.nrofactura,total:json.total,vuelto:json.vuelto,recibido:snapshot?.pago?.recibido??null,descuento:snapshot?.descuento??0,observacion:snapshot?.observacion??'',estado_venta:snapshot?.estado_venta??'CER',id_per:snapshot?.id_per??'',id_usuario:snapshot?.id_usuario??'',items:snapshot.items||[]}); }
  return json;
}
export { buildPayloadFromUI, guardarVenta, limpiarCarritoUI };
